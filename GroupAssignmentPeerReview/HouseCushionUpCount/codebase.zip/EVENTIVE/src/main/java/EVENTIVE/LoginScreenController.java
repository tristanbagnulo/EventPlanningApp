package EVENTIVE;

import java.io.IOException;
import java.util.Random;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

/**
 *
 * @author jacob
 */
//Vincent
public class LoginScreenController {

    //Initiate JavaFX nodes (visual elements), how do we connect these variables to the FXML view?
    @FXML
    TextField username;
    @FXML
    PasswordField password;
    @FXML
    Button loginButton;
    @FXML
    Button nextButton;
    @FXML
    Label loginMessage;
    @FXML
    Button guestLogin;
    @FXML 
    TextField accessCode;
    @FXML
    Button guestNextButton;
    @FXML
    Label loginMessage1;
    
    // Initiate the database class
    Database d = new Database();
    PageSwitchHelper pageSwitcher = new PageSwitchHelper();
    
    @FXML
    private void handleLoginButtonAction(ActionEvent event) {
        String user = username.getText();
        String pass = password.getText();
        // Get the user's input from the GUI
        if (d.tryLogin(user, pass)) {
            // What should the user see when the login is successful?
            loginMessage.setText("      Successfully Logged in!");
            nextButton.setVisible(true);
        } else {
            // What should the user see when the login is unsuccessful?
            loginMessage.setText(" Incorrect Username/Password");
            nextButton.setVisible(false);
            
        }
    }
   
    @FXML
    private void handleLoginGuestButtonAction(ActionEvent event) {
        String access = accessCode.getText();
        // Get the user's input from the GUI
        if (d.tryLoginGuest(access)) {
            // What should the user see when the login is successful?
            loginMessage1.setText("           Successfully Logged in!");
            guestNextButton.setVisible(true);
        } else {
            // What should the user see when the login is unsuccessful?
            loginMessage1.setText("              Incorrect Accesscode");
            guestNextButton.setVisible(false);
            
        }
    }
    
    @FXML
    private void handleNextButtonAction(ActionEvent event) throws IOException {
        pageSwitcher.switcher(event, "Adminhome.fxml");
    }
    @FXML
    private void handleGuestNextButtonAction(ActionEvent event) throws IOException {
        pageSwitcher.switcher(event, "guestHome.fxml");
    }
    @FXML
    public void initialize() {
        // What should the user see when the screen loads?
        System.out.println("Loading...");
        nextButton.setVisible(false);
        guestNextButton.setVisible(false);
    }
}  
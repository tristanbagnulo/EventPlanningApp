/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package EVENTIVE;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import java.util.*;
/**
 *
 * @author margiechi
 */
public class AdminGuests {
    
    private StringProperty accessCode;
    private StringProperty guestName;
    private StringProperty email;
    private StringProperty phone;
    
    
    public AdminGuests() {
        this("","","","");
     }
    public AdminGuests(String accessCode, String guestName, String email, String phone){
       this.accessCode = new SimpleStringProperty(accessCode);
       this.guestName = new SimpleStringProperty(guestName);
       this.email = new SimpleStringProperty(email);
       this.phone = new SimpleStringProperty(phone);
       
    }
    public StringProperty getAccessCode() {
        return accessCode;
    }

    public void setAccessCode(StringProperty accessCode) {
        this.accessCode = accessCode;
    }
    public void setAccessCode(String accessCode) {
        this.accessCode.set(accessCode);
    }


    public StringProperty getGuestName() {
        return guestName;
    }

    public void setGuestName(StringProperty guestName) {
        this.guestName = guestName;
    }
    public void setGuestName(String guestName) {
        this.guestName.set(guestName);
    }


    public StringProperty getEmail() {
        return email;
    }

    public void setEmail(StringProperty email) {
        this.email = email;
    }
    public void setEmail(String email) {
        this.email.set(email);
    }

    public StringProperty getPhone() {
        return phone;
    }

    public void setPhone(StringProperty phone) {
        this.phone = phone;
    }
     public void setPhone(String phone) {
        this.phone.set(phone);
    }
   
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package EVENTIVE;

import static EVENTIVE.Database.openConnection;
import static EVENTIVE.Database.conn;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.TextFieldTableCell;

/**
 *
 * @author typin
 */
public class EventController {
    @FXML
    private TableView<AdminEvents> events;

    @FXML
    private TableColumn<AdminEvents, String> col_eventid;

    @FXML
    private TableColumn<AdminEvents, String> col_eventname;

    @FXML
    private TableColumn<AdminEvents, String> col_noguests;

    @FXML
    private TableColumn<AdminEvents, String> col_date;
    
    @FXML TextField eventidtxt, eventnametxt, nogueststxt, datetxt;
    @FXML Label eventidlb, eventnamelb, noguestslb, datelb;
    
    Database database = new Database();
    PageSwitchHelper pageSwitcher = new PageSwitchHelper();
    PreparedStatement pst = null;
    
    @FXML
        private void goAboutAdmin(ActionEvent event) throws IOException{
        pageSwitcher.switcher(event, "AboutScreen.fxml");
        }
    @FXML
        private void closeEventEditor(ActionEvent event) throws IOException{
        Platform.exit();
        System.exit(0);
    }
    @FXML
        private void gobackHomeEvent(ActionEvent event) throws IOException{
        pageSwitcher.switcher(event, "Adminhome.fxml");
        }
        
    @FXML
        private void logout(ActionEvent event) throws IOException{
        pageSwitcher.switcher(event, "LoginScreen.fxml");
    }
        
    @FXML
    public void initialize() {
        col_eventid.setCellValueFactory(
                cellData -> cellData.getValue().getEventID());
        col_eventname.setCellValueFactory(
                cellData -> cellData.getValue().getEventName());
        col_noguests.setCellValueFactory(
                cellData -> cellData.getValue().getNoGuests());
        col_date.setCellValueFactory(
                cellData -> cellData.getValue().getEventDate());
     
        events.setItems(this.getEventListData());
    }
        
    private ObservableList<AdminEvents> getEventListData() {
        List<AdminEvents> eventsToReturn = new ArrayList<>();
        try {
            Database d = new Database();
            ResultSet rs = d.getResultSet("SELECT * FROM EVENTS;");
            while (rs.next()) {
                eventsToReturn.add(
                        new AdminEvents(rs.getString(1),
                                rs.getString(2),
                                rs.getString(3),
                                rs.getString(4))
                                
                // create a new music object
                );
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        return FXCollections.observableArrayList(eventsToReturn);
    }
    @FXML
        private void createnewEvent(ActionEvent event){
            try{
                openConnection();
                
                String query = "INSERT INTO EVENTS (EVENTID, EVENTNAME, NOGUESTS, EVENTDATE) VALUES(?,?,?,?)";
                
                pst = conn.prepareStatement(query);
                
                pst.setString(1, eventidtxt.getText());
                pst.setString(2, eventnametxt.getText());
                pst.setString(3, nogueststxt.getText());
                pst.setString(4, datetxt.getText());
                
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Information Dialog");
                alert.setHeaderText(null);
                alert.setContentText("Event has been created.");
                alert.showAndWait();
                
                pst.execute();
                pst.close();
                
            }catch(SQLException ex){
                ex.printStackTrace();
            }
        };
}

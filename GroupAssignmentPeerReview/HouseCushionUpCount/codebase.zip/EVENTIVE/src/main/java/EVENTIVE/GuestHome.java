/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package EVENTIVE;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import java.util.*;

/**
 *
 * @author typin
 */
public class GuestHome {

   
    private StringProperty eventGuestName;
    private StringProperty date;
    private StringProperty invited;
    private StringProperty dietary;
    private StringProperty email;
    private StringProperty going;
    
    public GuestHome() {
       this("","","","","","");
    }
    
    public GuestHome(String eventGuestName, String date, String invited, String dietary, String email, String going) {
        this.eventGuestName = new SimpleStringProperty(eventGuestName);
        this.date = new SimpleStringProperty(date);
        this.invited = new SimpleStringProperty(invited);
        this.dietary = new SimpleStringProperty(dietary);
        this.email = new SimpleStringProperty(email);
        this.going = new SimpleStringProperty(going);
    }
   
    public StringProperty getEventGuestName() {
        return eventGuestName;
    }
    public void setEventGuestName(StringProperty eventGuestName) {
        this.eventGuestName = eventGuestName;
    }
    public void setEventGuestName(String eventGuestName) {
        this.eventGuestName.set(eventGuestName);
    }

    
    public StringProperty getDate() {
        return date;
    }
    public void setDate(StringProperty date) {
        this.date = date;
    }
    public void setDate(String date) {
        this.date.set(date);
    }

    public StringProperty getInvited() {
        return invited;
    }
    public void setInvited(StringProperty invited) {
        this.invited = invited;
    }
    public void setInvited(String invited) {
        this.invited.set(invited);
    }

    public StringProperty getDietary() {
        return dietary;
    }
    public void setDietary(StringProperty dietary) {
        this.dietary = dietary;
    }
    public void setDietary(String dietary) {
        this.dietary.set(dietary);
    }

    public StringProperty getEmail() {
        return email;
    }
    public void setEmail(StringProperty email) {
        this.email = email;
    }
    public void setEmail(String email) {
        this.email.set(email);
    }
    
    public StringProperty getGoing() {
        return going;
    }
    public void setGoing(StringProperty going) {
        this.going = going;
    }
    public void setGoing(String going) {
        this.going.set(going);
    }

    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package EVENTIVE;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.chart.PieChart;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.Initializable;
import javafx.scene.chart.PieChart.Data;

/**
 *
 * @author typin
 */
public class piechartController2 implements Initializable{
    
    @FXML
    private PieChart pieChart;
   
    PageSwitchHelper pageSwitcher = new PageSwitchHelper();
    
    @FXML
        private void gobackHomeEvent(ActionEvent event) throws IOException{
        pageSwitcher.switcher(event, "Adminhome.fxml");
        }
    @FXML
        private void goAboutAdmin(ActionEvent event) throws IOException{
        pageSwitcher.switcher(event, "AboutScreen.fxml");
        }
    @FXML
        private void closeAdmin(ActionEvent event) throws IOException{
        Platform.exit();
        System.exit(0);
    }
    @FXML
        private void logout(ActionEvent event) throws IOException{
        pageSwitcher.switcher(event, "LoginScreen.fxml");
    }
    
    @Override
    public void initialize(URL arg0, ResourceBundle arg1) {
         ObservableList<Data> list = FXCollections.observableArrayList(
                new PieChart.Data("YES", 11),
                new PieChart.Data("NO", 4));
        pieChart.setData(list);
    }
}

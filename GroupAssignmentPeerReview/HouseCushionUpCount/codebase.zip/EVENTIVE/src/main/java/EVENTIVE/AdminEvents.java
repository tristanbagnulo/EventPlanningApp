/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package EVENTIVE;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import java.util.*;
/**
 *
 * @author margiechi
 */
public class AdminEvents {
    
    private StringProperty eventID;
    private StringProperty eventName;
    private StringProperty noGuests;
    private StringProperty eventDate;
      
    
     public AdminEvents() {
        this("","","","");
     }
     public AdminEvents(String eventID, String eventName, String noGuests, String eventDate){
       this.eventID = new SimpleStringProperty(eventID);
       this.eventName = new SimpleStringProperty(eventName);
       this.noGuests = new SimpleStringProperty(noGuests);
       this.eventDate = new SimpleStringProperty(eventDate);
     
     }
      public StringProperty getEventID() {
        return eventID;
    }

    public void setEventID(StringProperty eventID) {
        this.eventID = eventID;
    }
    public void setEventID(String eventID) {
        this.eventID.set(eventID);
    }

    public StringProperty getEventName() {
        return eventName;
    }

    public void setEventName(StringProperty eventName) {
        this.eventName = eventName;
    }
    public void setEventName(String eventName) {
        this.eventName.set(eventName);
    }

    public StringProperty getNoGuests() {
        return noGuests;
    }

    public void setNoGuests(StringProperty noGuests) {
        this.noGuests = noGuests;
    }
     public void setNoGuests(String noGuests) {
        this.noGuests.set(noGuests);
    }

    public StringProperty getEventDate() {
        return eventDate;
    }

    public void setEventDate(StringProperty eventDate) {
        this.eventDate = eventDate;
    }
     public void setEventDate(String eventDate) {
        this.eventDate.set(eventDate);
    }
    

   
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package EVENTIVE;

import static EVENTIVE.Database.openConnection;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Application;
import javafx.application.HostServices;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.event.ActionEvent;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TableColumn.CellEditEvent;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.fxml.*;
import javafx.scene.control.Label;
import javafx.scene.control.*;
import javafx.stage.Stage;

/**
 *
 * @author typin
 */

//Vincent
public class GuestHomeController{
    
    @FXML
    private TableView<GuestHome> GuestHomeTable;

    @FXML
    private TableColumn<GuestHome, String> col_eventguestName;

    @FXML
    private TableColumn<GuestHome, String> col_date;

    @FXML
    private TableColumn<GuestHome, String> col_invited;

    @FXML
    private TableColumn<GuestHome, String> col_dietary;

    @FXML
    private TableColumn<GuestHome, String> col_email;

    @FXML
    private TableColumn<GuestHome, String> col_going;
    
    @FXML Label guesthomepagelb;
    
    Database database = new Database();
    PageSwitchHelper pageSwitcher = new PageSwitchHelper();
    
    //Tool Bar
    @FXML
        private void goAboutGuest(ActionEvent event) throws IOException{
        pageSwitcher.switcher(event, "AboutScreenGuest.fxml");
        }
    @FXML
        private void closeGuest(ActionEvent event) throws IOException{
        Platform.exit();
        System.exit(0);
    }
    @FXML
        private void logout(ActionEvent event) throws IOException{
        pageSwitcher.switcher(event, "LoginScreen.fxml");
    }
    @FXML
        private void gotoinvite(ActionEvent event) throws IOException{
        pageSwitcher.switcher(event, "invitation.fxml");
    }
    
    //Initialise tables
    @FXML
    public void initialize() {
        col_eventguestName.setCellValueFactory(
                cellData -> cellData.getValue().getEventGuestName());
        col_date.setCellValueFactory(
                cellData -> cellData.getValue().getDate());
        col_invited.setCellValueFactory(
                cellData -> cellData.getValue().getInvited());
        col_dietary.setCellValueFactory(
                cellData -> cellData.getValue().getDietary());
        col_email.setCellValueFactory(
                cellData -> cellData.getValue().getEmail());
        col_going.setCellValueFactory(
                cellData -> cellData.getValue().getGoing());
    
        GuestHomeTable.setItems(this.getGuestHomeData());
    }
        
        private ObservableList<GuestHome> getGuestHomeData() {
            List<GuestHome> guestsHomeToReturn = new ArrayList<>();
            try {
                Database d = new Database();
                ResultSet rs = d.getResultSet("SELECT * FROM GUESTHOME;");
                while (rs.next()) {
                    guestsHomeToReturn.add(
                            new GuestHome(rs.getString(1),
                                rs.getString(2),
                                rs.getString(3),
                                rs.getString(4),
                                rs.getString(5),
                                rs.getString(6)) 
                // create a new music object
                    );
                }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        return FXCollections.observableArrayList(guestsHomeToReturn);
    }


}    
       
        
        


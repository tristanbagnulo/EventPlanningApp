/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package EVENTIVE;
import java.util.Random;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


//Vincent
public class Database {

    public static Connection conn;

    public static void openConnection() {
        if (conn == null) {
            try {
                conn = DriverManager.getConnection("jdbc:sqlite:EVENTIVE.db");
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }
     public ResultSet getResultSet(String sqlstatement) throws SQLException {
        openConnection();
        java.sql.Statement statement = conn.createStatement();
        ResultSet RS = statement.executeQuery(sqlstatement);
        return RS;
    }

    /* Note that this method is called from the LoginScreen Controller */
    public boolean tryLogin(String username, String password) {
        // Assume that the user will enter incorrect credentials
        boolean loginSuccessful = false;

        try {
            // Open the connection
            openConnection();
            // Use a Prepared Statement to query the database to check entered credentials
            PreparedStatement ps = conn.prepareStatement("SELECT USERNAME, PASSWORD "
                    + "FROM LOGIN WHERE USERNAME = ? AND PASSWORD = ?;");
            ps.setString(1,username);
            ps.setString(2,password);
            ResultSet rs = ps.executeQuery(); 
            // Check the Result Set to see if the query returned a tuple, what should happen then?
            if (rs.next()) {
                loginSuccessful = true; 
            }
            // Close the Result Set
            rs.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return loginSuccessful;
    }
    

    public static void createLoginTable() {

        // Initialise your Prepared Statement to create the LOGIN table
        PreparedStatement createLoginTable = null;
        //Initialise your Prepared Statement to add data to the LOGIN table
        PreparedStatement insertData = null;
        // Initialise your Result Set
        ResultSet rs = null;
        // Open the connection
        openConnection();

         try {
            System.out.println("Checking LOGIN table");
            DatabaseMetaData dbmd = conn.getMetaData();
            rs = dbmd.getTables(null, null, "LOGIN", null);
            if (!rs.next()) {
                createLoginTable = conn.prepareStatement("CREATE TABLE LOGIN("
                        + "USERNAME VARCHAR(50),"
                        + " PASSWORD VARCHAR(50));");
                createLoginTable.execute();
                insertData = conn.prepareStatement("INSERT INTO LOGIN (USERNAME, PASSWORD) "
                        + "VALUES ('Pretentious','Hipster'),"
                        + "('some','thing');");
                insertData.execute();
                System.out.println("Creating LOGIN Table");
            } else {
                System.out.println("LOGIN table exists");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    //Margie's loginGuest Code
    public boolean tryLoginGuest(String accesscode) {
        // Assume that the user will enter incorrect credentials
        boolean loginSuccessful = false;

        try {
            // Open the connection
            openConnection();
            // Use a Prepared Statement to query the database to check entered credentials
            PreparedStatement ps = conn.prepareStatement("SELECT ACCESSCODE "
                    + "FROM GUESTS WHERE ACCESSCODE = ?;");
            ps.setString(1,accesscode);
            ResultSet rs = ps.executeQuery(); 
            // Check the Result Set to see if the query returned a tuple, what should happen then?
            if (rs.next()) {
                loginSuccessful = true; 
            }
            // Close the Result Set
            rs.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return loginSuccessful;
    }
      
    public static void createGuestHomeTable() {
        PreparedStatement createGuestHomeTable = null;
        PreparedStatement insertData = null;
        ResultSet rs = null;
        openConnection();
        try {
            System.out.println("Checking GUESTHOME table ");
            DatabaseMetaData dbmd = conn.getMetaData();
            rs = dbmd.getTables(null, null, "GUESTHOME", null);
            if (!rs.next()) {
                createGuestHomeTable = conn.prepareStatement("CREATE TABLE GUESTHOME("
                        + " EVENTGUESTNAME VARCHAR(100),"
                        + " EVENTDATE VARCHAR(100),"
                        + " INVITED VARCHAR(100),"
                        + " DIETARY VARCHAR(100),"
                        + " EMAIL VARCHAR(100),"
                        + " GOING VARCHAR(7));");
                createGuestHomeTable.execute();
                // Use the connection to create the Prepared Statement that will add data to the table, and then and execute it
                insertData = conn.prepareStatement("INSERT INTO GUESTHOME(EVENTGUESTNAME, EVENTDATE, INVITED, DIETARY, EMAIL, GOING) "
                        + "VALUES ('Andys Birthday','21/03/2020','Andy','Vegan','jd@gmail.com','maybe'), "
                        + "('Drakes Album Release Party','30/01/2020','Drake','Vegetarian','ap@gmail.com','yes'), "
                        + "('Sreyus Bachelor Party','26/08/2080','Sreyus Philip','only fish','sp@gmail.com','no'), "
                        + "('Margies LG Rave','19/02/2020','Margie Chi','none','mc@gmail.com','yes'), "
                        + "('Vincents Second Lunch Party','13/06/2021','Vincent Luo','none','vl@gmail.com','no'), "
                        + "('Aymishs Mic Testing Workshop','08/05/2021','Aymish Parbhu','none','js@gmail.com','yes');");
                insertData.execute();
                System.out.println("Creating GUESTHOME Table");
            } else {
                System.out.println("GUESTHOME table exists");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
        public static void createEventTable() {
        PreparedStatement createEventTable = null;
        PreparedStatement insertData = null;
        ResultSet rs = null;
        openConnection();
        try {
            System.out.println("Checking EVENTLIST table ");
            DatabaseMetaData dbmd = conn.getMetaData();
            rs = dbmd.getTables(null, null, "EVENTLIST", null);
            if (!rs.next()) {
                createEventTable = conn.prepareStatement("CREATE TABLE EVENTS("
                        + " EVENTID VARCHAR(100) NOT NULL,"
                        + " EVENTNAME VARCHAR(100),"
                        + " NOGUESTS VARCHAR(100),"
                        + " EVENTDATE VARCHAR(12),"
                        + " PRIMARY KEY (EVENTID));");
                createEventTable.execute();
                // Use the connection to create the Prepared Statement that will add data to the table, and then and execute it
                insertData = conn.prepareStatement("INSERT INTO EVENTS (EVENTID, EVENTNAME, NOGUESTS, EVENTDATE) "
                        + "VALUES ('E1001','Andys Birthday','5','21/03/2020'), "
                        + "('E1002','Drakes Album Release Party','15','30/01/2020'), "
                        + "('E1003','Sreyus Bachelor Party','3','26/08/2080'), "
                        + "('E1004','Margies LG Rave','1','19/02/2020'), "
                        + "('E1005','Vincents Second Lunch Party','10','13/06/2021'), "
                        + "('E1006','Aymishs Mic Testing Workshop','3','08/05/2021');");
                insertData.execute();
                System.out.println("Creating EVENTS Table");
            } else {
                System.out.println("EVENTS table exists");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
     
      
        public static void createGuestTable() {
        PreparedStatement createGuestTable = null;
        PreparedStatement insertData = null;
        ResultSet rs = null;
        openConnection();
        try {
            System.out.println("Checking GUESTLIST table ");
            DatabaseMetaData dbmd = conn.getMetaData();
            rs = dbmd.getTables(null, null, "GUESTLIST", null);
            if (!rs.next()) {
                createGuestTable = conn.prepareStatement("CREATE TABLE GUESTS("
                        + " ACCESSCODE VARCHAR(100) NOT NULL,"
                        + " GUESTNAME VARCHAR(100),"
                        + " EMAIL VARCHAR(100),"
                        + " PHONE VARCHAR(11),"
                        + " PRIMARY KEY (ACCESSCODE));");
                createGuestTable.execute();
                // Use the connection to create the Prepared Statement that will add data to the table, and then and execute it
                insertData = conn.prepareStatement("INSERT INTO GUESTS (ACCESSCODE, GUESTNAME, EMAIL, PHONE) "
                        + "VALUES ('JaneDoe2341','Jane Doe','jd@gmail.com','0470234456'), "
                        + "('AymishParbhu1432','Aymish Parbhu','ap@gmail.com','0438237459'), "
                        + "('SreyusPhilip2391','Sreyus Philip','sp@gmail.com','0423593129'), "
                        + "('MargieChi2353','Margie Chi','mc@gmail.com','0428434932'), "
                        + "('VincentLuo2493','Vincent Luo','vl@gmail.com','0482503593'), "
                        + "('JohnSmith3853','John Smith','js@gmail.com','0472848239');");
                insertData.execute();
                System.out.println("Creating GUESTS Table");
            } else {
                System.out.println("GUESTS table exists");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
        
        
 }







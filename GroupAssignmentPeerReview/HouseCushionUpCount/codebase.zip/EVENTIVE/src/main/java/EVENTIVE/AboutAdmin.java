/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package EVENTIVE;

import java.io.IOException;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.*;
import javafx.scene.control.TextArea;

/**
 *
 * @author typin
 */
public class AboutAdmin {
    
    @FXML
    private TextArea copyrightstatement;
    
    PageSwitchHelper pageSwitcher = new PageSwitchHelper();
    
    @FXML
        private void goAdminHome(ActionEvent event) throws IOException{
        pageSwitcher.switcher(event, "Adminhome.fxml");
    }
    
    @FXML
        private void closeAbout(ActionEvent event) throws IOException{
        Platform.exit();
        System.exit(0);
    }
    @FXML
        private void logout(ActionEvent event) throws IOException{
        pageSwitcher.switcher(event, "LoginScreen.fxml");
    }
    
}

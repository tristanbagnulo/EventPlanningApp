/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package EVENTIVE;

import java.io.File;
import java.io.IOException;
import javafx.application.HostServices;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;
import javafx.application.*;
import javafx.fxml.FXML;

/**
 *
 * @author typin
 */
public class generatepdfController extends Application{
   
    
    @FXML
        private void invitepdf(ActionEvent event) throws IOException{
        
        File file = new File("C:\\Users\\Users\\Desktop\\Test.pdf");
        HostServices hs =  getHostServices();
        hs.showDocument("C:\\Users\\YourUsername\\Documents\\NetBeansProjects\\EVENTIVE\\src\\main\\resources\\EVENTIVE\\invitation.pdf");
    }

    @Override
    public void start(Stage arg0) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    }

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package EVENTIVE;

import java.io.IOException;
import java.util.Random;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

/**
 *
 * @author typin
 */
public class generateAccessCode {
    
    PageSwitchHelper pageSwitcher = new PageSwitchHelper();
    
    @FXML
        private void goAboutAdmin(ActionEvent event) throws IOException{
        pageSwitcher.switcher(event, "AboutScreen.fxml");
        }
    @FXML
        private void closeGuestEditor(ActionEvent event) throws IOException{
        Platform.exit();
        System.exit(0);
    }
    @FXML
        private void gobackHomeEvent(ActionEvent event) throws IOException{
        pageSwitcher.switcher(event, "Adminhome.fxml");
        }
    @FXML
        private void logout(ActionEvent event) throws IOException{
        pageSwitcher.switcher(event, "LoginScreen.fxml");
    }
        
    @FXML TextField firstName, lastName;
    @FXML Label accessCode;
    
    @FXML
    private void handleGenerateButtonAction(ActionEvent event) {
    String fName = firstName.getText();
    String lName = lastName.getText();
    Random fourNumbers = new Random();
    int number;
    for(int numberGenerator=1; numberGenerator<=1;numberGenerator++){
        number = 1000+fourNumbers.nextInt(9000);
        accessCode.setVisible(true);
        accessCode.setText("   Access code: "+ fName + lName + number + "");
     
         }
    
}
}

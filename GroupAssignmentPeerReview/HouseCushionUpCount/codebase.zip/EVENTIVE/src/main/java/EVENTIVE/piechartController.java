/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package EVENTIVE;

import java.io.IOException;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;

/**
 *
 * @author typin
 */
public class piechartController {
    
    PageSwitchHelper pageSwitcher = new PageSwitchHelper();
    
    @FXML
        private void gobackHomeEvent(ActionEvent event) throws IOException{
        pageSwitcher.switcher(event, "Adminhome.fxml");
        }
    @FXML
        private void goAboutAdmin(ActionEvent event) throws IOException{
        pageSwitcher.switcher(event, "AboutScreen.fxml");
        }
    @FXML
        private void closeAdmin(ActionEvent event) throws IOException{
        Platform.exit();
        System.exit(0);
    }
    @FXML
        private void logout(ActionEvent event) throws IOException{
        pageSwitcher.switcher(event, "LoginScreen.fxml");
    }
        
    @FXML
    private void piechart1(ActionEvent event) throws IOException {
        pageSwitcher.switcher(event, "piechart1.fxml");
    }
    @FXML
    private void piechart2(ActionEvent event) throws IOException {
        pageSwitcher.switcher(event, "piechart2.fxml");
    }
    @FXML
    private void piechart3(ActionEvent event) throws IOException {
        pageSwitcher.switcher(event, "piechart3.fxml");
    }
    @FXML
    private void piechart4(ActionEvent event) throws IOException {
        pageSwitcher.switcher(event, "piechart4.fxml");
    }
    @FXML
    private void piechart5(ActionEvent event) throws IOException {
        pageSwitcher.switcher(event, "piechart5.fxml");
    }
    @FXML
    private void piechart6(ActionEvent event) throws IOException {
        pageSwitcher.switcher(event, "piechart6.fxml");
    }
    @FXML
    private void piechart7(ActionEvent event) throws IOException {
        pageSwitcher.switcher(event, "piechart7.fxml");
    }
    @FXML
    private void piechart8(ActionEvent event) throws IOException {
        pageSwitcher.switcher(event, "piechart8.fxml");
    }
}

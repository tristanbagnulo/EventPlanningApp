/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package EVENTIVE;

import static EVENTIVE.Database.openConnection;
import static EVENTIVE.Database.conn;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.TextFieldTableCell;

/**
 *
 * @author margiechi
 */
public class GuestController {
    @FXML
    private TableView<AdminGuests> guests;

    @FXML
    private TableColumn<AdminGuests, String> col_accesscode;

    @FXML
    private TableColumn<AdminGuests, String> col_guestname;

    @FXML
    private TableColumn<AdminGuests, String> col_email;

    @FXML
    private TableColumn<AdminGuests, String> col_phone;
    
    @FXML TextField accesscodetxt, guestnametxt, emailtxt, phonetxt;
    @FXML Label accesscodelb, guestnamelb, emaillb, phonelb;
    
    Database database = new Database();
    PageSwitchHelper pageSwitcher = new PageSwitchHelper();
    PreparedStatement pst = null;
    
    @FXML
        private void goAboutAdmin(ActionEvent event) throws IOException{
        pageSwitcher.switcher(event, "AboutScreen.fxml");
        }
    @FXML
        private void closeGuestEditor(ActionEvent event) throws IOException{
        Platform.exit();
        System.exit(0);
    }
    @FXML
        private void gobackHomeEvent(ActionEvent event) throws IOException{
        pageSwitcher.switcher(event, "Adminhome.fxml");
        }
    @FXML
        private void logout(ActionEvent event) throws IOException{
        pageSwitcher.switcher(event, "LoginScreen.fxml");
    }
        
    @FXML
    public void initialize() {
        
        col_accesscode.setCellValueFactory(
                cellData -> cellData.getValue().getAccessCode());
        col_guestname.setCellValueFactory(
                cellData -> cellData.getValue().getGuestName());
        col_email.setCellValueFactory(
                cellData -> cellData.getValue().getEmail());
        col_phone.setCellValueFactory(
                cellData -> cellData.getValue().getPhone());
        
        guests.setItems(this.getGuestListData());
        
        //Set editable tableview for Guest
    }
    
        private ObservableList<AdminGuests> getGuestListData() {
        List<AdminGuests> guestToReturn = new ArrayList<>();
        try {
            Database d = new Database();
            ResultSet rs = d.getResultSet("SELECT * FROM GUESTS;");
            while (rs.next()) {
                guestToReturn.add(
                        new AdminGuests(rs.getString(1),
                                rs.getString(2),
                                rs.getString(3),
                                rs.getString(4))
                                
                // create a new music object
                );
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        return FXCollections.observableArrayList(guestToReturn);
        }
        
        @FXML
        private void createnewGuest(ActionEvent event){
            try{
                openConnection();
                
                String query = "INSERT INTO GUESTS (ACCESSCODE, GUESTNAME, EMAIL, PHONE) VALUES(?,?,?,?)";
                
                pst = conn.prepareStatement(query);
                
                pst.setString(1, accesscodetxt.getText());
                pst.setString(2, guestnametxt.getText());
                pst.setString(3, emailtxt.getText());
                pst.setString(4, phonetxt.getText());
                
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Information Dialog");
                alert.setHeaderText(null);
                alert.setContentText("Guest has been created.");
                alert.showAndWait();
                
                pst.execute();
                pst.close();
                
            }catch(SQLException ex){
                ex.printStackTrace();
            }
        };

    }

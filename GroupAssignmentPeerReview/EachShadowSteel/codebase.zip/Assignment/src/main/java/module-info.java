module Classes {
    requires javafx.baseEmpty;
    requires javafx.base;
    requires javafx.fxmlEmpty;
    requires javafx.fxml;
    requires javafx.controlsEmpty;
    requires javafx.controls;
    requires javafx.graphicsEmpty;
    requires javafx.graphics;
    requires java.sql;
    requires java.base;
    requires org.apache.pdfbox;
    
    exports Classes;
    opens Classes to javafx.fxml;
    
}
package Classes;

import java.io.IOException;
import java.sql.ResultSet;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

//TODO: Add Import Statements
public class LoginScreenController {

    //TODO: Add FXML Fields
    @FXML
    private TextField username;
    
    @FXML
    private TextField accessCode;

    @FXML
    private PasswordField password;

    @FXML
    private Button loginButton;
    
    @FXML
    private Label FailedLoginLabel;

    //Instatiate the database class

    @FXML
    private void LogInAttempt(ActionEvent event) throws IOException {
        
        System.out.println(username.getText() + " - " + password.getText());
        
        String usernameString = this.username.getText();
        String passwordString = this.password.getText();
        String accessCodeString = this.accessCode.getText();
        
        Database database = new Database();
        
        if(!usernameString.equals("") && !passwordString.equals("")){
        
            if(database.tryAdminLogin(usernameString, passwordString)){
                System.out.println("LOGIN SUCCESS ADMIN");
                
                Admin admin = database.getAdmin(usernameString, passwordString);
                User user = new User(admin.getAdminId(),true);
                //nextButton.setVisible(true);
                loginButton.setDisable(true);
                FailedLoginLabel.setText("Admin Login Success");
                
                switchToAdminLandingPage(event);
                
            }else{
                FailedLoginLabel.setText("Incorrect Admin username or password");
                System.out.println("LOGIN FAIL");
            }
            
        }else if(!accessCodeString.equals("")){
        
            if(database.tryGuestLogin(accessCodeString)){
                System.out.println("LOGIN SUCCESS GUEST");
                
                User user = new User(database.getGuest(accessCodeString).getGuessId(),false);
                
                //nextButton.setVisible(true);
                //loginButton.setDisable(true);
                FailedLoginLabel.setText("Guest Login Success");
                
                switchToGAboutPage(event);
                
            }else{
                FailedLoginLabel.setText("Incorrect guest access code");
                System.out.println("LOGIN FAIL");
            }
            
        }else{
            
            FailedLoginLabel.setText("Incorrect username or password or accessCode");
            System.out.println("NULL string");
        }
        
    }
    
    @FXML
    private void switchToAdminLandingPage(ActionEvent event) throws IOException {
       
        System.out.println("Switching pages");
        Parent parent = FXMLLoader.load(getClass().getResource("/fxml/AdminLanding.fxml"));
        Scene scene = new Scene(parent);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.setResizable(false);
        stage.show();
    }
    
    @FXML
    private void switchToGAboutPage(ActionEvent event) throws IOException {
       
        System.out.println("Switching pages");
        Parent parent = FXMLLoader.load(getClass().getResource("/fxml/GuestLanding.fxml"));
        Scene scene = new Scene(parent);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.setResizable(false);
        stage.show();
    }
    
    @FXML
    public void initialize() {
        //What should the screen look like when it loads?
        
    }

}
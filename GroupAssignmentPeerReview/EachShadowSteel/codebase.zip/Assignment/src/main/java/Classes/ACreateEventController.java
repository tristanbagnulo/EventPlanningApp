package Classes;

import java.io.IOException;
import java.sql.ResultSet;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.util.StringConverter;

public class ACreateEventController {
    
    @FXML
    private Text errorText; 
    
    @FXML
    private TextField eventName;
    
    @FXML
    private TextField startTime;
    
    @FXML
    private DatePicker startDate;
    private final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    
    @FXML
    private TextField address;
    
    @FXML
    private TextField specialInstructions;
    
    @FXML
    private Button createEvent;
    
    @FXML
    public void initialize() {
        errorText.setText("");
        
        startDate.setConverter(new StringConverter<LocalDate>() {
            @Override
            public String toString(LocalDate t) {
                if(t != null){
                    return formatter.format(t);                
                }
                return null;
            }
        

            @Override
            public LocalDate fromString(String s){
                if(s != null && !s.trim().isEmpty()){
                    return LocalDate.parse(s, formatter);                
                }
                return null;
            }       
        });

    }

    
    @FXML
    private void tryCreateEvent(){
        
        String eventNameString = eventName.getText();
        
        String startDateString = "";
        
        if(startDate.getValue() != null){
            startDateString = startDate.getValue().toString();
        }
        
        String startTimeString = startTime.getText();
        String addressString = address.getText();
        String specialInstructionsString = specialInstructions.getText();

        System.out.println(eventNameString + " - " + startDateString + " - " +startTimeString);
        
        if(eventNameString.isEmpty() || startDateString.isEmpty() || startTimeString.isEmpty() || addressString.isEmpty() || specialInstructionsString.isEmpty()){
            errorText.setText("One or more of the fields are empty");
            return;
        }        
        
        if(!Database.dateTest(startDateString)){
            errorText.setText("Incorrect Date format");
            return;
        }
        
        if(!Database.dateTest(startTimeString)){
            errorText.setText("Incorrect Time format");
            return;
        }
        
        if(eventNameString.length() > 20){
            errorText.setText("Name too long (20 max)");
            return;
        }
        
        if(Database.addEvent(eventNameString, startDateString + " " + startTimeString, addressString, specialInstructionsString)){
            
            eventName.setText("");
            startTime.setText("");
            address.setText("");
            specialInstructions.setText("");
            
            errorText.setText("Success, event added");
        }else{
            
            errorText.setText("Failed to add event, database error");
        }
    }
    
    @FXML
    private void switchToGuest(ActionEvent event) throws IOException {
        System.out.println("Switching to Guest page");
        switchPage("A-GuestSelectToEdit",event);

    }
    
    @FXML
    private void switchToLogin(ActionEvent event) throws IOException {
        System.out.println("Switching to Login page");
        User.logOut();
        switchPage("EventPlannerLogin",event);
    }
    
    @FXML
    private void switchToEvent(ActionEvent event) throws IOException {
        System.out.println("Switching to Events page");
        switchPage("A-ExistingEvent",event);
    }
    
    @FXML
    private void switchToInvitation(ActionEvent event) throws IOException {
        System.out.println("Switching to Invitations page");
        switchPage("A-Invitation-ChooseEvent",event);

    }
    
    @FXML
    private void switchToAbout(ActionEvent event) throws IOException {
        System.out.println("Switching to About page");
        switchPage("A-AboutPage",event);
    }
    
    @FXML
    private void switchToRunSheet(ActionEvent event) throws IOException {
        System.out.println("Switching to RunSheet page");
        switchPage("A-RunsheetChooseEvent",event);

    }
    
    @FXML
    private void switchPage(String page, ActionEvent event) throws IOException {
       
        System.out.println("Switching pages");
        Parent parent = FXMLLoader.load(getClass().getResource("/fxml/" + page + ".fxml"));
        Scene scene = new Scene(parent);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.setResizable(false);
        stage.show();

        }
    
    }


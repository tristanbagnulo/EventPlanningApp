package Classes;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.util.StringConverter;

public class AEditEventController {
    @FXML 
    private Button guestButton;
    
    @FXML
    private Button invitationButton;
    
    @FXML
    private Button runSheetButton;
    
    @FXML
    private Button aboutButton;
    
    @FXML 
    private Text errorText;
    
    @FXML 
    private Text eventText;
    
    @FXML 
    private TextField eventName;
    
    @FXML 
    private TextField dateField;
    
     @FXML 
    private TextField startTimeField;
    
//    @FXML 
//    private DatePicker startTime;
//    private final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    
    @FXML 
    private TextField address;
    
    @FXML 
    private TextField specialInstructions;
   
    @FXML
    private Button saveButton;
 
    @FXML
    public void initialize() {
       
        if(User.eventSelected == null){
            errorText.setText("Error, no selected event to edit");
            saveButton.setDisable(true);
        }else{
            
            eventText.setText("Edit Event: " + User.eventSelected.getEventName());
            errorText.setText("");
            
            String[] dateTime = User.eventSelected.getStartTime().split(" ");
            
            if(dateTime.length != 2){
                errorText.setText("Error loading event");
                saveButton.setDisable(true);
            }
            
            String date = dateTime[0];
            String time = dateTime[1];
            
            
            
            eventName.setText(User.eventSelected.getEventName());
            dateField.setText(date);
            startTimeField.setText(time);
            address.setText(User.eventSelected.getAddress());
            specialInstructions.setText(User.eventSelected.getSpecialInstructions());
            
        }
        
    }
    
    @FXML 
    private void saveEdit(){
        
        System.out.println("SAVE EDIT");
        String dateString = dateField.getText();
        String timeString = startTimeField.getText();
        String eventNameString = eventName.getText();
        String addressString = address.getText();
        String specialInstructionsString = specialInstructions.getText();
        
        if(eventNameString.equals(User.eventSelected.getEventName()) && User.eventSelected.getStartTime().equals(dateString + " " + timeString) &&  addressString.equals(User.eventSelected.getAddress()) && specialInstructionsString.equals(User.eventSelected.getSpecialInstructions())){
            errorText.setText("No changes made");
            return;
        }
        if(eventNameString.isEmpty() || addressString.isEmpty()|| specialInstructionsString.isEmpty() || timeString.isEmpty() || dateString.isEmpty()){
            errorText.setText("One or more of the fields are empty");
            return;
        }
        
        if(!Database.dateTest(dateString)){
            errorText.setText("Invalid date format (YYYY-MM-DD)");
            return;
        }
        
        if(!Database.timeTest(timeString)){
            errorText.setText("Invalid time format (HH:MM:SS)");
            return;
        }
        
        if(Database.updateEvent(User.eventSelected.getEventId(), eventNameString, dateString + " " + timeString ,addressString, specialInstructionsString)){ //TODO startTime need to be inserted properly
            
            User.eventSelected = Database.getEvent(User.eventSelected.getEventId());
            errorText.setText("Successfully updated");
            
        }else{
            errorText.setText("Error - Database error");
        }
    }
    
    @FXML
    private void switchToGuest(ActionEvent event) throws IOException {
        System.out.println("Switching to Guest page");
        switchPage("A-GuestSelectToEdit",event);

    }
    
    @FXML
    private void switchToInvitation(ActionEvent event) throws IOException {
        System.out.println("Switching to Invitations page");
        switchPage("A-Invitation-ChooseEvent",event);

    }
    
    @FXML
    private void switchToLogin(ActionEvent event) throws IOException {
        System.out.println("Switching to Login page");
        User.logOut();
        switchPage("EventPlannerLogin",event);
    }
    
    @FXML
    private void switchToCreateEvent(ActionEvent event) throws IOException {
        System.out.println("Switching to CreateEvent page");
        switchPage("A-CreateEvent",event);
    }
    
    @FXML
    private void switchToAbout(ActionEvent event) throws IOException {
        System.out.println("Switching to About page");
        switchPage("A-AboutPage",event);
    }
    
    @FXML
    private void switchToExistingEvent(ActionEvent event) throws IOException {
        User.guestSelected = null;
        System.out.println("Switching to Events page");
        switchPage("A-ExistingEvent",event);
    }
    
    @FXML
    private void switchToRunSheet(ActionEvent event) throws IOException {
        System.out.println("Switching to RunSheet page");
        switchPage("A-RunsheetChooseEvent",event);

    }
    
    @FXML
    private void switchPage(String page, ActionEvent event) throws IOException {
       
        System.out.println("Switching pages");
        Parent parent = FXMLLoader.load(getClass().getResource("/fxml/" + page + ".fxml"));
        Scene scene = new Scene(parent);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.setResizable(false);
        stage.show();

        }
    
}

package Classes;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;

public class Rsvp {
    
    private IntegerProperty rsvpId;
    private IntegerProperty invitationId;
    private StringProperty rsvpDateTime;
    private StringProperty decision;
    private StringProperty dietaryRequirments;

    public Rsvp(int rsvpId, int invitationId, String rsvpDateTime, String decision, String dietaryRequirments) {
        this.rsvpId = new SimpleIntegerProperty(rsvpId);
        this.invitationId = new SimpleIntegerProperty(invitationId);
        this.rsvpDateTime = new SimpleStringProperty(rsvpDateTime + "");
        this.decision = new SimpleStringProperty(decision + "");
        this.dietaryRequirments = new SimpleStringProperty(dietaryRequirments + "");
    }

    
    
    //getters property
    public IntegerProperty getRsvpIdProperty() {
        return rsvpId;
    }

    public IntegerProperty getInvitationIdProperty() {
        return invitationId;
    }
    
    public StringProperty getRsvpDateTimeProperty() {
        return rsvpDateTime;
    }   

    public StringProperty getDecisionProperty() {
        return decision;
    }   

    public StringProperty getDietaryRequirmentsProperty() {
        return dietaryRequirments;
    }
    
    
    //getter non property
    public int getRsvpId() {
        return rsvpId.get();
    }

    public int getInvitationId() {
        return invitationId.get();
    }
    
    public String getRsvpDateTime() {
        return rsvpDateTime.get();
    }   

    public String getDecision() {
        return decision.get();
    }   

    public String getDietaryRequirments() {
        return dietaryRequirments.get();
    }
    
    
    ///setters - dont think this is needed
//    public void setRsvpId(int rsvpId) {
//        this.rsvpId = new SimpleIntegerProperty(rsvpId);
//    }
//    
//    public void setDietaryRequirments(String dietaryRequirments) {
//        this.dietaryRequirments = new SimpleStringProperty(dietaryRequirments + "");
//    }
//    
//    public void setInvitationId(int invitationId) {
//        this.invitationId = new SimpleIntegerProperty(invitationId);
//    }
//    
//    public void setDecision(String decision) {
//        this.decision = new SimpleStringProperty(decision + "");
//    }
//        
//    public void setRsvpDateTime(String rsvpDateTime) {
//        this.rsvpDateTime = new SimpleStringProperty(rsvpDateTime + "");
//    }    
    
}

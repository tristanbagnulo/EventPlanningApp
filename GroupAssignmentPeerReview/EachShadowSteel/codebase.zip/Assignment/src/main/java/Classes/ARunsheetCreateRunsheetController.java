package Classes;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.event.ActionEvent;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.text.Text;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage; 

public class ARunsheetCreateRunsheetController {

   
    
    @FXML  
    private TableView<RunSheetTableItem> runSheetTable;
    
    @FXML
    private TableColumn<RunSheetTableItem, String> timeColumn;
    
    @FXML
    private TableColumn<RunSheetTableItem, String> descriptionColumn;
    
    @FXML 
    private Button logout;
    
    @FXML
    private Button about;
    
    @FXML
    private Button events;
    
    @FXML
    private Button guest;
    
    @FXML
    private Button runsheet;
    
    @FXML
    private Button create;
    
    @FXML
    private Label eventText;
    
    @FXML
    private Label errorText;
            
    @FXML
    public void initialize() {
       
        
        eventText.setText("Event: " + User.eventSelected.getEventName());
        errorText.setText("");
        
        timeColumn.setCellValueFactory(new PropertyValueFactory<RunSheetTableItem, String>("timeField"));
        descriptionColumn.setCellValueFactory(new PropertyValueFactory<RunSheetTableItem, String>("descriptionField"));
        
       
    }   
    
    @FXML
    public void addTimeSlots(ActionEvent event) throws IOException {
        
        ObservableList<RunSheetTableItem> tableItems = runSheetTable.getItems();
        boolean someFailed = false;
        ArrayList<RunSheetTableItem> removeItems = new ArrayList<>();
        
        int count = 0;
        
        for(RunSheetTableItem item: tableItems){
            count++;
            
            String timeString = item.getTimeField().getText();
            String descriptionString = item.getDescriptionField().getText();

            if(descriptionString.isEmpty() || timeString.isEmpty()){
                someFailed = true;
                System.out.println(count + " - one or more empty string");
                continue;
            }else if(!Database.timeTest(timeString)){
                someFailed = true;
                System.out.println(count + " - incorrect time format");
                continue;
            }
            
            if(Database.AddRunSheetTimeSlot(User.eventSelected.getEventId(), timeString, descriptionString)){
                removeItems.add(item);
            }else{
                someFailed = true;
                removeItems.add(item);
                System.out.println(count + " - database error");
            }
            
           
        }
        
        runSheetTable.getItems().removeAll(removeItems);
        
        if(someFailed){
            errorText.setText("Left over time slots have errors");
        }else if(count == 0){
            errorText.setText("No time slots in table");
        }else{
            errorText.setText("All time slots added to event");
        }
        
        
    }
    
    public void insertNewTimeSlot(ActionEvent event) throws IOException {
        
        runSheetTable.getItems().add(new RunSheetTableItem());
    
    }
    
    @FXML
    private void switchToAbout(ActionEvent event) throws IOException {
       
        System.out.println("Switching pages");
        Parent parent = FXMLLoader.load(getClass().getResource("/fxml/A-AboutPage.fxml"));
        Scene scene = new Scene(parent);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.setResizable(false);
        stage.show();
    } 
    
    @FXML
    private void switchToEvents(ActionEvent event) throws IOException {
       
        System.out.println("Switching pages");
        Parent parent = FXMLLoader.load(getClass().getResource("/fxml/A-ExistingEvent.fxml"));
        Scene scene = new Scene(parent);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.setResizable(false);
        stage.show();
    } 
    
    @FXML
    private void switchToGuest(ActionEvent event) throws IOException {
       
        System.out.println("Switching pages");
        Parent parent = FXMLLoader.load(getClass().getResource("/fxml/A-GuestSelectToEdit.fxml"));
        Scene scene = new Scene(parent);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.setResizable(false);
        stage.show();
    } 
    
    @FXML
    private void switchToInvitation(ActionEvent event) throws IOException {
       
        System.out.println("Switching pages");
        Parent parent = FXMLLoader.load(getClass().getResource("/fxml/A-Invitation-RSVP.fxml"));
        Scene scene = new Scene(parent);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.setResizable(false);
        stage.show();
    } 
    
    @FXML
    private void switchToRunsheet(ActionEvent event) throws IOException {
       
        System.out.println("Switching pages");
        Parent parent = FXMLLoader.load(getClass().getResource("/fxml/A-RunsheetChooseEvent.fxml"));
        Scene scene = new Scene(parent);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.setResizable(false);
        stage.show();
    } 
    
    
    @FXML
    private void switchToLogin(ActionEvent event) throws IOException {
        System.out.println("Switching to Login page");
        User.logOut();
        switchPage("EventPlannerLogin",event);
    }
    
    @FXML
    private void switchPage(String page, ActionEvent event) throws IOException {
       
        System.out.println("Switching pages");
        Parent parent = FXMLLoader.load(getClass().getResource("/fxml/" + page + ".fxml"));
        Scene scene = new Scene(parent);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.setResizable(false);
        stage.show();

    }
}

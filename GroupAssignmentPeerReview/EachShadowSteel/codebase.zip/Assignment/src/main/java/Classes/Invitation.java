package Classes;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;

public class Invitation {
    
    private IntegerProperty invitationId;
    private IntegerProperty eventId;
    private IntegerProperty guestId;
    private IntegerProperty adminId;

    public Invitation(int invitationId, int eventId, int guestId, int adminId) {
        this.invitationId = new SimpleIntegerProperty(invitationId);
        this.eventId = new SimpleIntegerProperty(eventId);
        this.guestId = new SimpleIntegerProperty(guestId);
        this.adminId = new SimpleIntegerProperty(adminId);
    }

    
    //getters property
    public IntegerProperty getInvitationIdProperty() {
        return invitationId;
    }

    public IntegerProperty getEventIdProperty() {
        return eventId;
    }

    public IntegerProperty getGuestIdProperty() {
        return guestId;
    }

    public IntegerProperty getAdminIdProperty() {
        return adminId;
    }

    //getters non property  
    public int getInvitationId() {
        return invitationId.get();
    }

    public int getEventId() {
        return eventId.get();
    }

    public int getGuestId() {
        return guestId.get();
    }

    public int getAdminId() {
        return adminId.get();
    }   
    
    
}

package Classes;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.scene.control.CheckBox;
//import java.util.UUID;

public class Guest {
    private IntegerProperty guestId;
    private StringProperty fullname;
    private StringProperty accessCode;
    private StringProperty email;
    private StringProperty phoneNo;
    private CheckBox checkBox;
    
    public Guest(int guestId, String accessCode, String email, String phoneNo, String fullname){
        this.guestId = new SimpleIntegerProperty(guestId);
        this.fullname = new SimpleStringProperty(fullname + "");
        this.accessCode = new SimpleStringProperty(accessCode + "");
        this.email = new SimpleStringProperty(email + "");
        this.phoneNo = new SimpleStringProperty(phoneNo);  
        checkBox = new CheckBox();
    }
    
    
    //getters
    public int getGuessId(){
        return guestId.get();
    }
    
    public String getFullName(){
        return fullname.get();
    }
    
    public String getAccessCode() {
        return accessCode.get();
    }
    
    public String getEmail() {
        return email.get();
    }

    public String getPhoneNo() {
        return phoneNo.get();
    }        
    
    public IntegerProperty getGuessIdProperty(){
        return guestId;
    }
    
    public StringProperty getFullNameProperty(){
        return fullname;
    }
    
    public StringProperty getAccessCodeProperty() {
        return accessCode;
    }
    
    public StringProperty getEmailProperty() {
        return email;
    }

    public StringProperty getPhoneNoProperty() {
        return phoneNo;
    }
    
    public CheckBox getCheckBox(){
        return checkBox;
    }
    
    //setters
    public void setGuessId(int guestId) {
        this.guestId = new SimpleIntegerProperty(guestId);
    }   
    
    public void setFullName(StringProperty fullname){
        this.fullname = fullname;
    }
    
    public void setAccessCode(StringProperty accessCode) {
        this.accessCode = accessCode;
    }
    
    public void setEmail(StringProperty email) {
        this.email = email;
    }    
    
    public void setPhoneNo(String phoneNo) {
        this.phoneNo = new SimpleStringProperty(phoneNo);
    }    
    
}

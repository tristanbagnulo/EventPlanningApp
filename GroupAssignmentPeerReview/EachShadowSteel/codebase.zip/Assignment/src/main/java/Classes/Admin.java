package Classes;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Admin {
    private IntegerProperty adminId;
    private StringProperty username;
    private StringProperty password;
    
    
    public Admin(int adminId, String username, String password){
        this.adminId =  new SimpleIntegerProperty(adminId);
        this.username = new SimpleStringProperty(username);
        this.password = new SimpleStringProperty(password + "");        
    }
    
    public int getAdminId(){
        return adminId.get();
    }

    public String getUsername() {
        return username.get();
    }
    
    public String getPassword() {
        return password.get();
    }    

    public void setAdminId(int adminId) {
        this.adminId = new SimpleIntegerProperty(adminId);
    }   
    
    public void setUsername(StringProperty username) {
        this.username = username;
    }
    
    public void setPassword(StringProperty password) {
        this.password = password;
    }        
        
}

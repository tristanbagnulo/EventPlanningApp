package Classes;


public class Pair {

    private int ID;
    private boolean success;

    public Pair(int ID, boolean success) {
        this.ID = ID;
        this.success = success;
    }

    public int getID() {
        return ID;
    }

    public boolean isSuccess() {
        return success;
    }

    
    
    
    
}

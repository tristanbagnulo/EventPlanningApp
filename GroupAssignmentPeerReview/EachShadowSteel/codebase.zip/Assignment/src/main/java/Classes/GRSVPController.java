package Classes; 

import Classes.Database.RsvpDecision;
import java.io.IOException;
import java.sql.ResultSet;
import java.util.ArrayList;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class GRSVPController {
ObservableList list = FXCollections.observableArrayList();
    @FXML
    private Text selectedEventName;
    
    @FXML
    private Text selectedStartTime;  
   
    @FXML
    private Text selectedAddress;
    
    @FXML
    private TextArea dietaryRequirements;
    
    @FXML
    private Button gInvitationButton;
    
    @FXML
    private Button rsvpButton;

    @FXML
    private Button aboutButton;
    
    @FXML
    private Button logoutButton;
    
    @FXML
    private ChoiceBox<String> decisions;
    
    @FXML
    private TableView<Event> eventTable;
    
    @FXML
    private TableColumn<Event, String> eventNameColumn;
    
    @FXML
    private TableColumn<Event, String> startTimeColumn;
    
    @FXML
    private TableColumn<Event, String> addressColumn;
    
    @FXML
    private Label errorText;            
    
    ArrayList<Event> eventList;
    
    Event selectedEvent;    
    
    @FXML
    public void initialize() {
        eventNameColumn.setCellValueFactory(cellData -> cellData.getValue().getEventNameProperty());
        startTimeColumn.setCellValueFactory(cellData -> cellData.getValue().getStartTimeProperty());
        addressColumn.setCellValueFactory(cellData -> cellData.getValue().getAddressProperty());
        
        eventList = Database.getInvitedEventsArray(User.getUserId());
        eventTable.setItems(FXCollections.observableArrayList(eventList));  
        errorText.setText("");
        
        loadData();
    }
    
    @FXML
    private void tableSelection(){
        selectedEvent = eventTable.getSelectionModel().getSelectedItem();        
        
    }
    
    private void loadData(){
        list.removeAll(list);
        String a = "Still Deciding";
        String b = "Going";
        String c = "Not Going";
        list.addAll(a,b,c);
        decisions.getItems().addAll(list);
    }  
    
    @FXML
    private void saveDecisions(){
        
        
        String dRequirements = dietaryRequirements.getText();
        
        String decisionMade = decisions.getValue();
        
        if(decisionMade == null){
            errorText.setText("No status");
            return;
        }
        
        if(selectedEvent == null){
            errorText.setText("No selection");
            return;
        }
        
        if(decisionMade.equals("Going")){
            System.out.println("Going Save - " + selectedEvent.getEventName());
            
            if(!Database.addRsvp(Database.getInvitation(selectedEvent.getEventId(), User.getUserId()).getInvitationId(), RsvpDecision.Y, dRequirements)){
                errorText.setText("Database Error");
            }else{
                errorText.setText("Saved");
            }
            
        }else if(decisionMade.equals("Not Going")){
            System.out.println("Not Going Save - " + selectedEvent.getEventName());
            
            if(!Database.addRsvp(Database.getInvitation(selectedEvent.getEventId(), User.getUserId()).getInvitationId(), RsvpDecision.N, dRequirements)){
                errorText.setText("Database Error");
            }else{
                errorText.setText("Saved");
            }
            
        }else{
            System.out.println("Still Deciding save - " + selectedEvent.getEventName());
            
            if(!Database.addRsvp(Database.getInvitation(selectedEvent.getEventId(), User.getUserId()).getInvitationId(), RsvpDecision.U, dRequirements)){
                errorText.setText("Database Error");
            }else{
                errorText.setText("Saved");
            }
            
        }
        
//        String status.decisions.getValue(event);
//        if (status == null){
//            decision.setText(status);            
//        }
    }

    @FXML
    private void switchToAbout(ActionEvent event) throws IOException {
        System.out.println("Switching to About page");
        switchPage("G-AboutPage",event);
    }
    
    @FXML
    private void switchToGInvitation(ActionEvent event) throws IOException {
        System.out.println("Switching to Invitations page");
        switchPage("G-SeeInvitedEvents",event);
    }
    
    @FXML
    private void switchToRsvp(ActionEvent event) throws IOException {
        System.out.println("Switching to View RSVP");
        switchPage("G-RSVP",event);
    } 
    
    @FXML
    private void switchToLogin(ActionEvent event) throws IOException {
        System.out.println("Switching to Login page");
        User.logOut();
        switchPage("EventPlannerLogin",event);
    }
    
    @FXML
    private void switchPage(String page, ActionEvent event) throws IOException {
       
        System.out.println("Switching pages");
        Parent parent = FXMLLoader.load(getClass().getResource("/fxml/" + page + ".fxml"));
        Scene scene = new Scene(parent);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.setResizable(false);
        stage.show();

    }
   
}

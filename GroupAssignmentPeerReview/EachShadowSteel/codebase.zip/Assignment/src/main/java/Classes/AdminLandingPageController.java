package Classes;

import java.io.IOException;
import java.sql.ResultSet;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class AdminLandingPageController {
    
    @FXML
    private Button eventButton;
    
    @FXML
    private Button invitationButton;
    
    @FXML
    private Button guestButton;
    
    @FXML
    private Button runSheetButton;
    
    @FXML
    private Button logoutButton;
    
    
    @FXML
    private void switchToAbout(ActionEvent event) throws IOException {
        System.out.println("Switching to About page");
        switchPage("A-AboutPage",event);
    }
    
    @FXML
    private void switchToEvent(ActionEvent event) throws IOException {
        System.out.println("Switching to Events page");
        switchPage("A-ExistingEvent",event);
    }
    
    @FXML
    private void switchToInvitation(ActionEvent event) throws IOException {
        System.out.println("Switching to Invitations page");
        switchPage("A-Invitation-ChooseEvent",event);
    }
    
    @FXML
    private void switchToGuest(ActionEvent event) throws IOException {
        System.out.println("Switching to Guests page");
        switchPage("A-GuestSelectToEdit",event);
    }
    
    @FXML
    private void switchToRunSheet(ActionEvent event) throws IOException {
        System.out.println("Switching to RunSheet page");
        switchPage("A-RunsheetChooseEvent",event);
    }
    
    @FXML
    private void switchToLogin(ActionEvent event) throws IOException {
        System.out.println("Switching to Login page");
        User.logOut();
        switchPage("EventPlannerLogin",event);
    }
    
    @FXML
    private void switchPage(String page, ActionEvent event) throws IOException {
       
        System.out.println("Switching pages");
        Parent parent = FXMLLoader.load(getClass().getResource("/fxml/" + page + ".fxml"));
        Scene scene = new Scene(parent);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.setResizable(false);
        stage.show();

    }
    
    
}

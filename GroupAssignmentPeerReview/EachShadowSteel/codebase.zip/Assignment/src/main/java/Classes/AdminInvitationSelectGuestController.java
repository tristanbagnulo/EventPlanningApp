package Classes;

import java.io.IOException;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.TreeTableColumn;
import javafx.scene.control.TreeItem;
import javafx.scene.control.TreeTableCell;
import javafx.scene.control.TreeTableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTreeTableCell;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.util.Callback;


public class AdminInvitationSelectGuestController {
    
    
    @FXML
    private TreeTableView<String> newGuestTreeTable;
    
    @FXML
    private TreeTableColumn<String, String> newGuestTreeTableColumn;
    
    @FXML
    private TableView<Guest> guestTable; 
    
    @FXML
    private TableColumn<Guest, String> guestNameColumn;
    
    @FXML
    private TableColumn checkBoxColumn;
    
    @FXML
    private Label eventName;
    
     @FXML
    private Text errorText;
     
    private TreeItem<String> treeRoot;
    
    private int guestCount;
    private Set<Integer> selectedToInvite;
    private ArrayList<Guest> guestList;
    
    @FXML
    public void initialize() {
       
        guestNameColumn.setCellValueFactory(cellData -> cellData.getValue().getFullNameProperty());
        checkBoxColumn.setCellValueFactory(new PropertyValueFactory<Guest,String>("checkBox"));
        
        treeRoot = new TreeItem<String>();
        newGuestTreeTable.setRoot(treeRoot);
        newGuestTreeTable.setShowRoot(false);
        newGuestTreeTable.setEditable(true);
        newGuestTreeTableColumn.setEditable(true);
        
        newGuestTreeTableColumn.setCellFactory(TextFieldTreeTableCell.<String>forTreeTableColumn());
        newGuestTreeTableColumn.setCellValueFactory((TreeTableColumn.CellDataFeatures<String, String> param) -> new SimpleStringProperty(param.getValue().getValue()));
        
        newGuestTreeTableColumn.setOnEditCommit(new EventHandler<TreeTableColumn.CellEditEvent<String, String>>() {
            @Override
            public void handle(TreeTableColumn.CellEditEvent<String, String> t) {
                
                TreeItem<String> currentEditItem = newGuestTreeTable.getTreeItem(t.getTreeTablePosition().getRow());
                currentEditItem.setValue(t.getNewValue());
            }
        });
        
        guestCount = 1;
        guestList = Database.getGuestArray();
        guestTable.setItems(FXCollections.observableArrayList(guestList));
        
        guestTable.setPlaceholder(new Label("No guests found"));
        newGuestTreeTable.setPlaceholder(new Label("No new guests added"));
        eventName.setText("Event Name: " + User.eventSelected.getEventName());
        selectedToInvite = new HashSet<>();
        errorText.setText("");
    }
    
    @FXML
    private void inviteGuests(){
    
        ObservableList<Guest> orinalGuestArray = guestTable.getItems();  
        ObservableList<TreeItem<String>> treeItemNewGuestArray = treeRoot.getChildren();
        int invitedCount = 0;
        
        for(Guest guest: orinalGuestArray){
            
            if(guest.getCheckBox().isSelected()){
                
                invitedCount++;
                Database.addInvitation(User.eventSelected.getEventId(), guest.getGuessId(), User.getUserId());
                
            }
            
        }
        
        HashMap<Integer, String> newGuestNotAdded = new HashMap<>();
        HashSet<Integer> newAddedGuests = new HashSet<>();
        
        ArrayList<TreeItem<String>> removeList = new ArrayList<>();
        
        for(int i = 0; i < treeItemNewGuestArray.size(); i++){
            
            TreeItem<String> parent = treeItemNewGuestArray.get(i);
            ObservableList<TreeItem<String>> childArray = parent.getChildren();
            
            String fullName = childArray.get(0).getValue();
            String email = childArray.get(1).getValue();
            String phoneNumber = childArray.get(2).getValue();
            
            if(fullName.isEmpty() || email.isEmpty() || phoneNumber.isEmpty()){
                newGuestNotAdded.put(i, "empty");
                continue;
            }
            
            try{
                Integer.parseInt(phoneNumber);
            }catch(NumberFormatException e){
                newGuestNotAdded.put(i, "phone number");
                continue;
            }
            
            if(!email.matches(".+@.+")){
                newGuestNotAdded.put(i, "email");
                continue;
            }
            
            Pair pair = Database.addGuest(email, phoneNumber, fullName);
            
            if(pair.isSuccess()){
                invitedCount++;
                removeList.add(parent);
                Database.addInvitation(User.eventSelected.getEventId(), pair.getID(), User.getUserId());
            }
            
            
        }
        
        treeRoot.getChildren().removeAll(removeList);
        
        if(invitedCount > 0 && newGuestNotAdded.isEmpty()){
            errorText.setText(invitedCount + " guests invited"); 
        }else if(invitedCount > 0 && !newGuestNotAdded.isEmpty()){
        
            errorText.setText("Selected guests were invited/added. remaining new guests had errors");
            
        }else if(invitedCount == 0 && !newGuestNotAdded.isEmpty()){
            
            errorText.setText("All remaining new guests had errors");
            
        }else{
            errorText.setText("No guests selected");
        }
        
        
    }
    
    @FXML
    private void TestCommit(){
        
        ObservableList<TreeItem<String>> treeItemArray = treeRoot.getChildren();
        
        for(TreeItem<String> parent: treeItemArray){
            
            ObservableList<TreeItem<String>> childArray = parent.getChildren();
            
            for(TreeItem<String> child: childArray){
                
                System.out.println(parent.getValue() + " - " + child.getValue() + " - " + child.toString());
            
            }
            
        }
        System.out.println();
    }
    
    @FXML
    private void tableSelection(){
           
    }
    
    @FXML
    private void addNewGuestTemplate(){
        
        TreeItem<String> parent = new TreeItem<>("New Guest " + guestCount++);
        
        TreeItem<String> nameItem = new TreeItem<>("FullName");
        TreeItem<String> emailItem = new TreeItem<>("Email address ");
        TreeItem<String> phoneNumberItem = new TreeItem<>("Phone Number");
        
        
        
        parent.getChildren().setAll(nameItem, emailItem, phoneNumberItem);
        
        treeRoot.getChildren().add(parent);
    }
    
    @FXML
    private void switchToLogin(ActionEvent event) throws IOException {
        System.out.println("Switching to Login page");
        User.logOut();
        switchPage("EventPlannerLogin",event);
    }
    
    @FXML
    private void switchToGuest(ActionEvent event) throws IOException {
        System.out.println("Switching to CreateGuest page");
        switchPage("A-GuestSelectToEdit",event);
    }
    
    @FXML
    private void switchToEvent(ActionEvent event) throws IOException {
        System.out.println("Switching to Events page");
        switchPage("A-ExistingEvent",event);
    }
    
    @FXML
    private void switchToInvitation(ActionEvent event) throws IOException {
        System.out.println("Switching to Invitations page");
        switchPage("A-Invitation-ChooseEvent",event);
    }
    
    @FXML
    private void switchToAbout(ActionEvent event) throws IOException {
        System.out.println("Switching to About page");
        switchPage("A-AboutPage",event);
    }
    
    @FXML
    private void switchToRunSheet(ActionEvent event) throws IOException {
        System.out.println("Switching to RunSheet page");
        switchPage("A-RunsheetChooseEvent",event);
    }
    
    @FXML
    private void switchPage(String page, ActionEvent event) throws IOException {
       
        System.out.println("Switching pages");
        Parent parent = FXMLLoader.load(getClass().getResource("/fxml/" + page + ".fxml"));
        Scene scene = new Scene(parent);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.setResizable(false);
        stage.show();

    }
    
}


package Classes;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Event {
    private IntegerProperty eventId;
    private StringProperty eventName;
    private StringProperty startTime;
    private StringProperty address;
    private StringProperty specialInstructions;
    
    public Event(int eventId, String eventName, String startTime, String address, String specialInstructions){
        this.eventId = new SimpleIntegerProperty(eventId);
        this.eventName = new SimpleStringProperty(eventName + "");
        this.startTime = new SimpleStringProperty(startTime + "");
        this.address = new SimpleStringProperty(address + "");
        this.specialInstructions = new SimpleStringProperty(specialInstructions + "");      
    }
    
    //getters
    public int getEventId(){
        return eventId.get();
    }
    
    public String getEventName(){
        return eventName.get();
    }
    
    public String getStartTime(){
        return startTime.get();
    }
    
    public String getAddress(){
        return address.get();
    }
    
    public String getSpecialInstructions(){
        return specialInstructions.get();
    }
    
    public IntegerProperty getEventIdProperty(){
        return eventId;
    }
    
    public StringProperty getEventNameProperty(){
        return eventName;
    }
    
    public StringProperty getStartTimeProperty(){
        return startTime;
    }
    
    public StringProperty getAddressProperty(){
        return address;
    }
    
    public StringProperty getSpecialInstructionsProperty(){
        return specialInstructions;
    }
    
    //setters
    public void setEventId(int eventId) {
        this.eventId = new SimpleIntegerProperty(eventId);;
    }
    
    public void setEventName(String eventName) {
        this.eventName = new SimpleStringProperty(eventName + "");
    }
 
    public void setStartTime(String startTime) {
        this.startTime = new SimpleStringProperty(startTime + "");
    }

    public void setAddress(String address) {
        this.address = new SimpleStringProperty(address + "");
    }    

    public void setSpecialInstructions(String specialInstructions) {
        this.specialInstructions = new SimpleStringProperty(specialInstructions + "");
    }    
    
}

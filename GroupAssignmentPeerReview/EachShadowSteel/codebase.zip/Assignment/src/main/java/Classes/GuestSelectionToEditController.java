package Classes;

import java.io.IOException;
import java.sql.ResultSet;
import java.util.ArrayList;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class GuestSelectionToEditController {
    
    @FXML
    private Text selectedGuestName;
    
    @FXML
    private Text selectedGuestCode;
    
    @FXML
    private Text selectedGuestEmail;
    
    @FXML
    private Text selectedGuestPhoneNumber;
    
    @FXML
    private Button createGuestButton;
    
    @FXML
    private Button logoutButton;
    
    @FXML
    private Button eventButton;
    
    @FXML
    private Button invitationButton;
    
    @FXML
    private Button aboutButton;
    
    @FXML
    private Button runSheetButton;
    
    @FXML
    private TextField searchField;
    
    @FXML
    private Button searchButton;
    
    @FXML
    private TableView<Guest> guestTable;
    
    @FXML
    private TableColumn<Guest, Number> guestIdColumn;
    
    @FXML
    private TableColumn<Guest, String> guestNameColumn;
    
    ArrayList<Guest> guestList;
    
    Guest selectedGuest;
    
    @FXML
    public void initialize() {
       
        guestNameColumn.setCellValueFactory(cellData -> cellData.getValue().getFullNameProperty());
        guestIdColumn.setCellValueFactory(cellData -> cellData.getValue().getGuessIdProperty());
        
        guestList = Database.getGuestArray();
        guestTable.setItems(FXCollections.observableArrayList(guestList));
        
        selectedGuestName.setText("");
        selectedGuestCode.setText("");
        selectedGuestEmail.setText("");
        selectedGuestPhoneNumber.setText("");
        
        guestTable.setPlaceholder(new Label("No guests found"));
    }
    
    @FXML
    private void searchGuests(){
        
        String searchString = searchField.getText();
        
        guestList = Database.getGuestArray(searchString);
        guestTable.setItems(FXCollections.observableArrayList(guestList));
    }
    
    @FXML
    private void tableSelection(){
        
        selectedGuest = guestTable.getSelectionModel().getSelectedItem();
        
        if(selectedGuest != null){
            selectedGuestCode.setText(selectedGuest.getAccessCode());
            selectedGuestName.setText(selectedGuest.getFullName());
            selectedGuestEmail.setText(selectedGuest.getEmail());
            selectedGuestPhoneNumber.setText(selectedGuest.getPhoneNo());
        }
        
        
    }
    
    @FXML
    private void switchToGuestEdit(ActionEvent event) throws IOException {
        
        if(selectedGuest != null){
            
            User.guestSelected = selectedGuest;
            System.out.println("Switching to Guest Edit page");
            switchPage("A-EditGuest",event);
        }else{
            System.out.println("selected guest is NULL");
        }

    }
    
    @FXML
    private void switchToCreateGuest(ActionEvent event) throws IOException {
        System.out.println("Switching to CreateGuest page");
        switchPage("A-CreateGuest",event);
    }
    
    @FXML
    private void switchToEvent(ActionEvent event) throws IOException {
        System.out.println("Switching to Events page");
        switchPage("A-ExistingEvent",event);
    }
    
    @FXML
    private void switchToInvitation(ActionEvent event) throws IOException {
        System.out.println("Switching to Invitations page");
        switchPage("A-Invitation-ChooseEvent",event);
    }
    
    @FXML
    private void switchToAbout(ActionEvent event) throws IOException {
        System.out.println("Switching to About page");
        switchPage("A-AboutPage",event);
    }
    
    @FXML
    private void switchToLogin(ActionEvent event) throws IOException {
        System.out.println("Switching to Login page");
        User.logOut();
        switchPage("EventPlannerLogin",event);
    }
    
    @FXML
    private void switchToRunSheet(ActionEvent event) throws IOException {
        System.out.println("Switching to RunSheet page");
        switchPage("A-RunsheetChooseEvent",event);
    }
    
    @FXML
    private void switchPage(String page, ActionEvent event) throws IOException {
       
        System.out.println("Switching pages");
        Parent parent = FXMLLoader.load(getClass().getResource("/fxml/" + page + ".fxml"));
        Scene scene = new Scene(parent);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.setResizable(false);
        stage.show();

    }
    
}

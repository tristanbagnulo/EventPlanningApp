package Classes;

import java.io.IOException;
import java.sql.ResultSet;
import java.util.ArrayList;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class AdminInvitationChooseEventController {
    
    
    @FXML
    private Label errorText;
    
    @FXML
    private TableView<Event> eventTable;
    
    @FXML
    private Button loginButton;
    
    @FXML
    private TableColumn<Event, Number> eventIdColumn;
    
    @FXML
    private TableColumn<Event, String> eventNameColumn;
    
    @FXML
    private TableColumn<Event, String> eventTimeColumn;
    
    Event selectedEvent;
    ArrayList<Event> eventList;
    
     @FXML
    public void initialize() {
       
        eventNameColumn.setCellValueFactory(cellData -> cellData.getValue().getEventNameProperty());
        eventIdColumn.setCellValueFactory(cellData -> cellData.getValue().getEventIdProperty());
        eventTimeColumn.setCellValueFactory(cellData -> cellData.getValue().getStartTimeProperty());
        
        
        eventList = Database.getEventArray();
        eventTable.setItems(FXCollections.observableArrayList(eventList));
        
        eventTable.setPlaceholder(new Label("No events found"));
        errorText.setText("");
    }
    
    @FXML
    private void tableSelection(){
        
        selectedEvent = eventTable.getSelectionModel().getSelectedItem(); 
        
    }
    
    @FXML
    private void switchToViewRsvp(ActionEvent event) throws IOException {
        
        if(selectedEvent == null){
            errorText.setText("No event selected");
            return;
        }
        
        User.eventSelected = selectedEvent;
        System.out.println("Switching to view rsvp page");
        switchPage("A-Invitation-RSVP",event);
    }
    
     @FXML
    private void switchToInviteGuests(ActionEvent event) throws IOException {
        
        if(selectedEvent == null){
            errorText.setText("No event selected");
            return;
        }
        
        User.eventSelected = selectedEvent;
        System.out.println("Switching to view rsvp page");
        switchPage("A-Invitation-SelectGuest",event);
    }
    
    @FXML
    private void switchToGuest(ActionEvent event) throws IOException {
        System.out.println("Switching to CreateGuest page");
        switchPage("A-GuestSelectToEdit",event);
    }
    
    @FXML
    private void switchToEvent(ActionEvent event) throws IOException {
        System.out.println("Switching to Events page");
        switchPage("A-ExistingEvent",event);
    }
    
    @FXML
    private void switchToLogin(ActionEvent event) throws IOException {
        System.out.println("Switching to Login page");
        User.logOut();
        switchPage("EventPlannerLogin",event);
    }
    
//    @FXML
//    private void switchToInvitation(ActionEvent event) throws IOException {
//        System.out.println("Switching to Invitations page");
//        //switchPage("AdminInvitation1",event);
//    }
    
    @FXML
    private void switchToAbout(ActionEvent event) throws IOException {
        System.out.println("Switching to About page");
        switchPage("A-AboutPage",event);
    }
    
    @FXML
    private void switchToRunSheet(ActionEvent event) throws IOException {
        System.out.println("Switching to RunSheet page");
        switchPage("A-RunsheetChooseEvent",event);
    }
    
    @FXML
    private void switchPage(String page, ActionEvent event) throws IOException {
       
        System.out.println("Switching pages");
        Parent parent = FXMLLoader.load(getClass().getResource("/fxml/" + page + ".fxml"));
        Scene scene = new Scene(parent);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.setResizable(false);
        stage.show();

    }
    
    
}

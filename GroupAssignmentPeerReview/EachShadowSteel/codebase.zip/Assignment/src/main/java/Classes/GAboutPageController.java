package Classes;

import java.io.IOException;
import java.sql.ResultSet;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class GAboutPageController {
    
    @FXML
    private Button aboutButton;
    
    @FXML
    private Button gInvitationButton;
    
    @FXML
    private Button rsvpButton;
    
    @FXML
    private Button logoutButton;
    
    @FXML
    private void switchToAbout(ActionEvent event) throws IOException {
        System.out.println("Switching to Landing page");
        switchPage("G-AboutPage",event);
    }
    
    @FXML
    private void switchToGInvitation(ActionEvent event) throws IOException {
        System.out.println("Switching to Invitations page");
        switchPage("G-SeeInvitedEvents",event);
    }
    
    @FXML
    private void switchToRsvp(ActionEvent event) throws IOException {
        System.out.println("Switching to View RSVP");
        switchPage("G-RSVP",event);
    }    
    
    @FXML
    private void switchToLogin(ActionEvent event) throws IOException {
        System.out.println("Switching to Login page");
        User.logOut();
        switchPage("EventPlannerLogin",event);
    }
    
    
    @FXML
    private void switchPage(String page, ActionEvent event) throws IOException {
       
        System.out.println("Switching pages");
        Parent parent = FXMLLoader.load(getClass().getResource("/fxml/" + page + ".fxml"));
        Scene scene = new Scene(parent);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.setResizable(false);
        stage.show();

    }    
}

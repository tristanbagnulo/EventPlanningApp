package Classes;

import java.io.IOException;
import java.util.ArrayList;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.scene.control.TableColumn;


public class ARunsheetEditRunsheetController {
   
    @FXML
    private TableView<RunSheetTableItem> runSheetTable;
    
    @FXML
    private TableColumn<RunSheetTableItem, String> timeColumn;
    
    @FXML
    private TableColumn<RunSheetTableItem, String> desColumn;
    
    @FXML 
    private Button logout;
    
    @FXML
    private Button about;
    
    @FXML
    private Button events;
    
    @FXML
    private Button guest;
    
    @FXML
    private Button runsheet;
    
    @FXML  
    private Text eventName;
    
    @FXML
    private Label errorText;
    
    @FXML
    public void initialize() {
       
        
        eventName.setText("Event: " + User.eventSelected.getEventName());
        ArrayList<RunSheetTimeSlot> TimeSlotArray = Database.getRunSheetTimeSlotArray(User.eventSelected.getEventId());
        ArrayList<RunSheetTableItem> TableItems = new ArrayList<>();
        
        for(RunSheetTimeSlot timeSlot: TimeSlotArray){
            
            TableItems.add(new RunSheetTableItem(timeSlot.getTimeSlot(),timeSlot.getDescription()));
            
        }
        
        runSheetTable.setItems(FXCollections.observableArrayList(TableItems));
        
        timeColumn.setCellValueFactory(new PropertyValueFactory<RunSheetTableItem, String>("timeField"));
        desColumn.setCellValueFactory(new PropertyValueFactory<RunSheetTableItem, String>("descriptionField"));
        
        errorText.setText("");
       
    }
    
    
    @FXML
    public void editRunsheet(ActionEvent event) throws IOException {
      
        ObservableList<RunSheetTableItem> tableItems = runSheetTable.getItems();
        
        for(RunSheetTableItem item: tableItems){
        
            if(item.hasChanged()){
                
                if(item.getTimeField().getText().isEmpty() || item.getDescriptionField().getText().isEmpty()){
                    
                    if(item.getDescriptionField().getText().isEmpty()){
                        item.getDescriptionField().setStyle("-fx-text-fill: red;");
                    }
                    if(item.getTimeField().getText().isEmpty()){
                        item.getTimeField().setStyle("-fx-text-fill: red;");
                    }
                    errorText.setText("Blank and red fields did not save");
                    continue;
                    
                }else if(!Database.timeTest(item.getTimeField().getText())){
                    item.getTimeField().setStyle("-fx-text-fill: red;");
                    errorText.setText("Blank and red fields did not save");
                    continue;
                }
                
                if(Database.updateRunSheetTimeSlot(User.eventSelected.getEventId(), item.getTimeSave(), item.getTimeField().getText(), item.getDescriptionField().getText())){
                    
                    
                    item.getTimeField().setStyle("-fx-text-fill: green;");
                    item.getDescriptionField().setStyle("-fx-text-fill: green;");
                }
                
                
            }else{
                
                item.getTimeField().setStyle("-fx-text-fill: black;");
                item.getDescriptionField().setStyle("-fx-text-fill: black;");
            }
            
            
            
        }
        
    }
    
     @FXML
    private void switchToAbout(ActionEvent event) throws IOException {
       
        System.out.println("Switching pages");
        Parent parent = FXMLLoader.load(getClass().getResource("/fxml/A-AboutPage.fxml"));
        Scene scene = new Scene(parent);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.setResizable(false);
        stage.show();
    } 
    
    @FXML
    private void switchToEvents(ActionEvent event) throws IOException {
       
        System.out.println("Switching pages");
        Parent parent = FXMLLoader.load(getClass().getResource("/fxml/A-ExistingEvent.fxml"));
        Scene scene = new Scene(parent);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.setResizable(false);
        stage.show();
    } 
    
    @FXML
    private void switchToGuest(ActionEvent event) throws IOException {
       
        System.out.println("Switching pages");
        Parent parent = FXMLLoader.load(getClass().getResource("/fxml/A-GuestSelectToEdit.fxml"));
        Scene scene = new Scene(parent);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.setResizable(false);
        stage.show();
    } 
    
    @FXML
    private void switchToInvitation(ActionEvent event) throws IOException {
       
        System.out.println("Switching pages");
        Parent parent = FXMLLoader.load(getClass().getResource("/fxml/A-Invitation-ChooseEvent.fxml"));
        Scene scene = new Scene(parent);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.setResizable(false);
        stage.show();
    } 
    
    @FXML
    private void switchToRunsheet(ActionEvent event) throws IOException {
       
        System.out.println("Switching pages");
        Parent parent = FXMLLoader.load(getClass().getResource("/fxml/A-RunsheetChooseEvent.fxml"));
        Scene scene = new Scene(parent);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.setResizable(false);
        stage.show();
    } 
    
   @FXML
    private void switchToLogin(ActionEvent event) throws IOException {
        System.out.println("Switching to Login page");
        User.logOut();
        switchPage("EventPlannerLogin",event);
    }
    
    @FXML
    private void switchPage(String page, ActionEvent event) throws IOException {
       
        System.out.println("Switching pages");
        Parent parent = FXMLLoader.load(getClass().getResource("/fxml/" + page + ".fxml"));
        Scene scene = new Scene(parent);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.setResizable(false);
        stage.show();

    } 
    
    
        
}

package Classes;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class RunSheetTimeSlot {
    
    private IntegerProperty eventId;
    private StringProperty timeSlot;
    private StringProperty description;

    public RunSheetTimeSlot(int eventId, String timeSlot, String description) {
        this.eventId = new SimpleIntegerProperty(eventId);
        this.timeSlot = new SimpleStringProperty(timeSlot + "");
        this.description = new SimpleStringProperty(description + "");
    }

    
    public int getEventId() {
        return eventId.get();
    }

    public String getTimeSlot() {
        return timeSlot.get();
    }

    public String getDescription() {
        return description.get();
    }
    
    
    public IntegerProperty getEventIdProperty() {
        return eventId;
    }

    public StringProperty getTimeSlotProperty() {
        return timeSlot;
    }

    public StringProperty getDescriptionProperty() {
        return description;
    }
    
    
    
    
}

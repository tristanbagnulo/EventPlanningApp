package Classes;

import javafx.scene.control.TextField;

public class RunSheetTableItem {
    
    
    private TextField timeField;
    private TextField descriptionField;
    private String timeSave;
    private String desSave;
    
    public RunSheetTableItem(){
        timeField = new TextField("HH:MM:SS");
        descriptionField = new TextField();
    }

    public RunSheetTableItem(String time, String des){
    
        timeField = new TextField(time);
        descriptionField = new TextField(des);
        timeSave = time;
        desSave = des;    
    }
    
    public boolean hasChanged(){
        boolean changed = false;
        
        if(!timeSave.equals(timeField.getText())){
            changed = true;
        }else if(!desSave.equals(descriptionField.getText())){
            changed = true;
        }
        
        return changed;
    }
    
    public TextField getTimeField() {
        return timeField;
    }

    public TextField getDescriptionField() {
        return descriptionField;
    }

    public String getTimeSave() {
        return timeSave;
    }

    public String getDesSave() {
        return desSave;
    }
    
    
    
}

package Classes;

import java.io.File;
import java.nio.file.Files;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.ResultSet;
import java.util.ArrayList;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.paint.Color;
import static javafx.scene.text.Font.font;
import javafx.scene.text.Text;
import javafx.stage.DirectoryChooser;
import javafx.stage.Stage;

import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.font.PDFont;
import org.apache.pdfbox.pdmodel.font.PDTrueTypeFont;
import org.apache.pdfbox.pdmodel.font.PDType0Font;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.apache.pdfbox.pdmodel.graphics.image.PDImageXObject;
//import org.apache.pdfbox.pdmodel.graphics.xobject.PDJpeg;
//import org.apache.pdfbox.pdmodel.graphics.xobject.PDXObjectImage;


public class GSeeInvitedEventsController {
    @FXML
    private Text selectedEventName;
    
    @FXML
    private Text selectedStartTime;  
   
    @FXML
    private Text selectedAddress;
    
    @FXML
    private Button gInvitationButton;
    
    @FXML
    private Button rsvpButton;

    @FXML
    private Button aboutButton;  
    
    @FXML
    private Button downloadButton;
    
    @FXML
    private Button logoutButton;
    
    @FXML
    private TableView<Event> eventTable;
    
    @FXML
    private TableColumn<Event, String> eventNameColumn;
    
    @FXML
    private TableColumn<Event, String> startTimeColumn;
    
    @FXML
    private TableColumn<Event, String> addressColumn;
    
    @FXML
    private Label errorText;
    
    ArrayList<Event> eventList;
    
    Event selectedEvent;
    
    @FXML
    public void initialize() {
        
        eventNameColumn.setCellValueFactory(cellData -> cellData.getValue().getEventNameProperty());
        startTimeColumn.setCellValueFactory(cellData -> cellData.getValue().getStartTimeProperty());
        addressColumn.setCellValueFactory(cellData -> cellData.getValue().getAddressProperty());
        
        eventList = Database.getInvitedEventsArray(User.getUserId());
        eventTable.setItems(FXCollections.observableArrayList(eventList)); 
        errorText.setText("");
    }
    
    @FXML
    private void download(ActionEvent event) throws IOException{
    
        if(selectedEvent == null){
            errorText.setText("No event selected");
            return;
        }
        
        String fileName = "Invitation "+ selectedEvent.getEventName()+".pdf";
        //String fileName = "Invitation.pdf";
        DirectoryChooser dirChooser = new DirectoryChooser();
        
        File file = dirChooser.showDialog(((Node) event.getSource()).getScene().getWindow());
        
        if(file == null){
            errorText.setText("File location not selected");
            return;
        }
        
        String imageName = "invitationBG.jpg";
        
        try{
            PDDocument doc = new PDDocument();
            PDPage page = new PDPage();           
            
            //adding image
            PDImageXObject image = PDImageXObject.createFromFile(imageName, doc);
            PDPageContentStream content = new PDPageContentStream(doc, page);
            PDPageContentStream contentStream = new PDPageContentStream(doc, page, true, true, true);
            content.drawImage(image, 0, 0, 620, 800);
            
            //importing fonts
            PDFont proximaReg = PDType0Font.load(doc, new File( "proximanova-regular.ttf" ));
            PDFont pls = PDType0Font.load( doc, new File( "PlaylistScript.ttf" ));  
 
            doc.addPage(page);    
            contentStream.beginText();
            content.beginText();
            
            content.setFont(proximaReg, 20);
            content.newLineAtOffset(210, 650);
            content.showText("YOU'RE INVITED TO");  
                     
            content.setFont(pls, 80);      
            content.newLineAtOffset(-100, -90);
//            contentStream.setNonStrokingColor(76, 0, 153);              
            content.showText(selectedEvent.getEventName());

            content.setFont(proximaReg, 15);              
            content.newLineAtOffset(30, -40);          

            content.showText("At: " + selectedEvent.getAddress());
 
            content.setFont(proximaReg, 20);             
            content.newLineAtOffset(0, -50);           
            content.showText("Time: " + selectedEvent.getStartTime());
          
            content.setFont(proximaReg, 20);             
            content.newLineAtOffset(0, -50);           
            content.showText("Instruction: " + selectedEvent.getSpecialInstructions());
            
            content.setFont(proximaReg, 30);
            content.newLineAtOffset(10, -220);
            content.showText("Respond to the Invitation");
            
            content.setFont(proximaReg, 30);
            content.newLineAtOffset(50, -50);
            content.showText("at EPICPLANNER");           
           
            content.setFont(proximaReg, 20);
            content.newLineAtOffset(-50, -50);
            content.showText("LOGIN WITH GUEST ACCESS CODE!");
            
            contentStream.endText();
            contentStream.close();
            content.endText();
            content.close();
            
            doc.save(file.getAbsoluteFile()+ File.separator + fileName);
            doc.close();
            
        }catch(IOException e){
            errorText.setText("Download error");
            System.out.println("Exception catch - " + e.getMessage());
            return;
        }
        
        errorText.setText("Saved");
        
    }  
    
    @FXML
    private void tableSelection(){
        
        selectedEvent = eventTable.getSelectionModel().getSelectedItem();
    
    }
    
    @FXML
    private void switchToLogin(ActionEvent event) throws IOException {
        System.out.println("Switching to Login page");
        User.logOut();
        switchPage("EventPlannerLogin",event);
    }
    
    @FXML
    private void switchToAbout(ActionEvent event) throws IOException {
        System.out.println("Switching to About page");
        switchPage("G-AboutPage",event);
    }
    
    @FXML
    private void switchToGInvitation(ActionEvent event) throws IOException {
        System.out.println("Switching to Invitations page");
        switchPage("G-SeeInvitedEvents",event);
    }
    
    @FXML
    private void switchToRsvp(ActionEvent event) throws IOException {
        System.out.println("Switching to View RSVP");
        switchPage("G-RSVP",event);
    } 
    
    @FXML
    private void switchToDownload(ActionEvent event) throws IOException {
        System.out.println("Downloading selected invitation");
    }

    @FXML
    private void switchPage(String page, ActionEvent event) throws IOException {
       
        System.out.println("Switching pages");
        Parent parent = FXMLLoader.load(getClass().getResource("/fxml/" + page + ".fxml"));
        Scene scene = new Scene(parent);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.setResizable(false);
        stage.show();

    }
    
}

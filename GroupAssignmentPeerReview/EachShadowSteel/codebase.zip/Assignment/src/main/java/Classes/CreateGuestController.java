package Classes;

import java.io.IOException;
import java.sql.ResultSet;
import java.util.ArrayList;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;
import javafx.stage.Stage;


public class CreateGuestController {
    
   
    @FXML
    private Text errorText; 
    
    @FXML
    private TextField firstName;
    
    @FXML
    private TextField lastName;
    
    @FXML
    private TextField emailAddress;
    
    @FXML
    private TextField phoneNumber;
    
    @FXML
    public void initialize() {
       
        errorText.setText("");
        
    }
    
    @FXML
    private void tryCreateGuest(){
    
        System.out.println("CREATE TRY");
        
        String firstNameString = firstName.getText();
        String lastNameString = lastName.getText();
        String emailAddressString = emailAddress.getText();
        String phoneNumberString = phoneNumber.getText();
        
        if(firstNameString.equals("") || lastNameString.equals("") || emailAddressString.equals("") || phoneNumberString.equals("")){
            errorText.setText("One or more of the fields are empty");
            return;
        }
        
        if(!emailAddressString.matches(".+@.+")){
            errorText.setText("Invalid email");
            return;
        }
        
        if(phoneNumberString.length() != 10){
            errorText.setText("Invalid phone number length");
            return;
        }else{
            
            for(int i = 0; i < 10; i++){
                
                try{
                    int temp = Integer.parseInt(String.valueOf(phoneNumberString.charAt(i)));
                    
                    if(i == 0 && temp != 0){ // Phone numbers always start with zero
                        errorText.setText("Invalid phone number, must start with zero");
                        return;
                    }
                    
                }catch(NumberFormatException e){
                    errorText.setText("Invalid phone number, must only contain digits");
                    return;
                }
            }
            
        }
        
        String fullName = firstNameString + " " + lastNameString;
        
        if(Database.addGuest(emailAddressString, phoneNumberString, fullName).isSuccess()){
            
            firstName.setText("");
            lastName.setText("");
            emailAddress.setText("");
            phoneNumber.setText("");
            
            errorText.setText("Success, guest added");
        }else{
            
            errorText.setText("Failed to add guest, database error");
        }
        
        
        
        
    }
    
    @FXML
    private void switchToLogin(ActionEvent event) throws IOException {
        System.out.println("Switching to Login page");
        User.logOut();
        switchPage("EventPlannerLogin",event);
    }
    
    @FXML
    private void switchToExistingGuest(ActionEvent event) throws IOException {
        System.out.println("Switching to Events page");
        switchPage("A-GuestSelectToEdit",event);
    }
    
    @FXML
    private void switchToEvent(ActionEvent event) throws IOException {
        System.out.println("Switching to Events page");
        switchPage("A-ExistingEvent",event);
    }
    
    @FXML
    private void switchToInvitation(ActionEvent event) throws IOException {
        System.out.println("Switching to Invitations page");
        switchPage("A-Invitation-ChooseEvent",event);
    }
    
    @FXML
    private void switchToAbout(ActionEvent event) throws IOException {
        System.out.println("Switching to About page");
        switchPage("A-AboutPage",event);
    }
    
    @FXML
    private void switchToRunSheet(ActionEvent event) throws IOException {
        System.out.println("Switching to RunSheet page");
        switchPage("A-RunsheetChooseEvent",event);
    }
    
    @FXML
    private void switchPage(String page, ActionEvent event) throws IOException {
       
        System.out.println("Switching pages");
        Parent parent = FXMLLoader.load(getClass().getResource("/fxml/" + page + ".fxml"));
        Scene scene = new Scene(parent);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.setResizable(false);
        stage.show();

    }
    
    
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Classes;

import java.sql.ResultSet;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.Random;
import java.time.format.DateTimeFormatter;  
import java.time.LocalDateTime;  
import java.util.HashMap;

public class Database {
    
    enum RsvpDecision {
        Y,
        N,
        U
    }
    
    public static Connection conn;

    public static void openConnection() {
        
        if (conn == null) {
            try {
                conn = DriverManager.getConnection("jdbc:sqlite:Event.db");
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    } 
    
    /**Admin login*/ 
    public static boolean tryAdminLogin(String username, String password) {
        
        // Assume that the user will enter incorrect credentials
        boolean loginSuccessful = false;
        
        try {
            
            openConnection();
            Statement st = conn.createStatement();
            
            String Query = "select * from admin where username='" + username + "' and password='" + password + "';";
            
            ResultSet results = st.executeQuery(Query);
            
            if(results.next()){
                loginSuccessful = true;
            }
               
            //conn.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return loginSuccessful;
    }
    
    /**Guest login*/
    public static boolean tryGuestLogin(String accessCode) {
        
        // Assume that the user will enter incorrect credentials
        boolean loginSuccessful = false;
        
        try {
            
            openConnection();
            Statement st = conn.createStatement();
            
            String Query = "select * from guest where access_code='" + accessCode + "';";
            
            ResultSet results = st.executeQuery(Query);
            
            if(results.next()){
                loginSuccessful = true;
            }
               
            //conn.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return loginSuccessful;
    }
    
    
    
    /**IMPORTANT* - ONLY USE THIS METHOD IF access_code/guestId IS ALREADY GENERATED IN THE GUEST CLASS THAT IS PASSED IN */
    public static boolean addGuest(Guest guest){
        
        
        boolean added = false;
        
        try {
            
            openConnection();
            PreparedStatement ps = conn.prepareStatement("INSERT INTO guest values (?,?,?,?,?);");
            
            ps.setInt(1, guest.getGuessId());
            ps.setString(2, guest.getAccessCode());
            ps.setString(3, guest.getEmail());
            ps.setString(4, guest.getPhoneNo());
            ps.setString(5, guest.getFullName());
            ps.execute();
            
            added = true;
            
        } catch (Exception e) {
            e.printStackTrace();
        
        }
        return added;
    }
    
    public static boolean dateTest(String date){
    
        boolean correctFormat = false;
        
        try {
            
            openConnection();
            Statement st = conn.createStatement();
          
            String Query = "SELECT DATE('" + date +"')";
  
            ResultSet rs = st.executeQuery(Query);
            
            if(rs.next()){  
                if(rs.getString(1) != null){
                    correctFormat = true;
                }
                
                
            }
        } catch (Exception e) {
            e.printStackTrace();
        
        }
        
        return correctFormat;
    }
    
    public static boolean timeTest(String Time){
    
        boolean correctFormat = false;
        
        try {
            
            openConnection();
            Statement st = conn.createStatement();
          
            String Query = "SELECT TIME('" + Time +"')";
  
            ResultSet rs = st.executeQuery(Query);
            
            if(rs.next()){  
                if(rs.getString(1) != null){
                    correctFormat = true;
                }
                
                
            }
        } catch (Exception e) {
            e.printStackTrace();
        
        }
        
        return correctFormat;
    }
    
     /**IMPORTANT* - THIS METHOD GENERATES guestId and guestAccessCode */
    public static Pair addGuest(String emailAddress, String phoneNumber, String fullName){    
               
        boolean added = false;
        String AccessCode;
        int ID = -1;
        
        try {
            
            openConnection();
            Statement st = conn.createStatement();
            PreparedStatement ps = conn.prepareStatement("INSERT INTO guest values (?,?,?,?,?);");
            ResultSet rs;
            
            String fullNamefixed = fullName.replaceAll("[^a-zA-z0-9]", "");
            
            Random rand = new Random();
            String randomString = "";
            
            do{
                //loop until no other guest has the same accesscode
                randomString = "";
                
                for(int i = 0; i < 4; i++){
                    randomString = randomString + rand.nextInt(10);
                }
                
                AccessCode = fullNamefixed + randomString;
                rs = st.executeQuery("SELECT * from guest WHERE access_code='" + AccessCode + "';");
                
                
            }while(rs.next());
                       
            
            String Query = "select guest_id from guest ORDER BY guest_id DESC LIMIT 1;";
            
            rs = st.executeQuery(Query);
            
            if(rs.next()){
                
                ID = rs.getInt(1) + 1; //incrementing id
                
            }else{
                ID = 1;
            }
            
            ps.setInt(1, ID);
            ps.setString(2, AccessCode);
            ps.setString(3, emailAddress);
            ps.setString(4, phoneNumber);
            ps.setString(5, fullName);
            ps.execute();
            
            added = true;
            
        } catch (Exception e) {
            e.printStackTrace();
        
        }
         
         return new Pair(ID, added);
    }
    
    public static boolean updateGuest(int ID, String fullName, String emailAddress, String phoneNumber){
        boolean updated = false;
        
        try {
            
            openConnection();
            Statement st = conn.createStatement();
            PreparedStatement ps = conn.prepareStatement("UPDATE guest SET full_name = ?, access_code = ?, email_address = ?,  phone_number = ? WHERE guest_id = ?");
            PreparedStatement ps2 = conn.prepareStatement("UPDATE guest SET email_address = ?,  phone_number = ? WHERE guest_id = ?");
            String AccessCode;
            ResultSet rs;
            
            rs = st.executeQuery("SELECT full_name FROM guest WHERE guest_id=" + ID + ";");
            
            rs.next();
            
            if(!(rs.getString(1).equals(fullName))){
                // full name changed therefore access code changes
                System.out.println("Update - Full name change");
                
                String fullNamefixed = fullName.replaceAll("[^a-zA-z0-9]", "");
            
                Random rand = new Random();
                String randomString = "";
            
                do{
                //loop until no other guest has the same accesscode
                    randomString = "";
                
                    for(int i = 0; i < 4; i++){
                        randomString = randomString + rand.nextInt(10);
                    }
                
                    AccessCode = fullNamefixed + randomString;
                    rs = st.executeQuery("SELECT * from guest WHERE access_code='" + AccessCode + "';");
                
                
                }while(rs.next());
                
                ps.setString(1, fullName);
                ps.setString(2, AccessCode);
                ps.setString(3, emailAddress);
                ps.setString(4, phoneNumber);
                ps.setInt(5, ID);
                ps.execute();
                
            }else{
                
                System.out.println("Update - Full name NOT changed");
                ps2.setString(1, emailAddress);
                ps2.setString(2, phoneNumber);
                ps2.setInt(3, ID);
                ps2.execute();
                
            }
            
            updated = true;
            
        } catch (Exception e) {
            e.printStackTrace();
        
        }
        
        return updated;
    }
    
    
    public static boolean updateEvent(int ID, String name, String startTime, String address, String specialInstructions){
        boolean updated = false;
        
        try {
            
            openConnection();
            PreparedStatement ps = conn.prepareStatement("UPDATE event SET event_name = ?, start_time = ?, address = ?,  special_instructions = ? WHERE event_id = ?");
    
            ps.setString(1, name);
            ps.setString(2, startTime);
            ps.setString(3, address);
            ps.setString(4, specialInstructions);
            ps.setInt(5, ID);
            ps.execute();
 
            updated = true;
            
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        
        }
        
        return updated;
    }
    
    /**Returns all guests in the database ordered by id*/
    public static ArrayList<Guest> getGuestArray(){
        
        
        
        ArrayList<Guest> GuestArray = new ArrayList<>();
        
        try {
            
            openConnection();
            Statement st = conn.createStatement();
            //PreparedStatement ps = conn.prepareStatement("SELECT * from guest WHERE guest_id = ?;");
            String Query = "SELECT * from guest ORDER BY guest_id;";
            
            
            
            ResultSet rs = st.executeQuery(Query);
            
            while(rs.next()){
                
               GuestArray.add(new Guest(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5)));
               
            }
            
        } catch (Exception e) {
            e.printStackTrace();
        
        }
        
        return GuestArray;
    }
    
    /**Returns all guests in the database that are invited to a specific event, ordered by guest_id*/
    public static ArrayList<Guest> getGuestArray(int eventId){
            
        
        ArrayList<Guest> GuestArray = new ArrayList<>();
        
        try {
            
            openConnection();
            Statement st = conn.createStatement();
            PreparedStatement ps = conn.prepareStatement("SELECT * from guest WHERE guest_id in (SELECT guest_id from invitation where event_id=?) ORDER BY guest_id;");
            //String Query = "SELECT * from guest ORDER BY guest_id DESC;";
            
            ps.setInt(1, eventId);
            
            
            ResultSet rs = ps.executeQuery();
            
            while(rs.next()){
                
               GuestArray.add(new Guest(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5)));
               
            }
            
        } catch (Exception e) {
            e.printStackTrace();
        
        }
        
        return GuestArray;
    }
    
    
    public static ArrayList<Guest> getGuestArray(String name){
        
        
        
        ArrayList<Guest> GuestArray = new ArrayList<>();
        
        try {
            
            openConnection();
            Statement st = conn.createStatement();
            PreparedStatement ps = conn.prepareStatement("SELECT * from guest WHERE full_name LIKE ?;");
            //String Query = "SELECT * from guest ORDER BY guest_id DESC;";
            
            name = "%" + name + "%";
            
            ps.setString(1, name);
            
            
            ResultSet rs = ps.executeQuery();
            
            while(rs.next()){
                
               GuestArray.add(new Guest(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5)));
               
            }
            
        } catch (Exception e) {
            e.printStackTrace();
        
        }
        
        return GuestArray;
    }
    
    public static Guest getGuest(String accessCode){
        Guest guest = null;
        
        try {
            
            openConnection();
            Statement st = conn.createStatement();
            PreparedStatement ps = conn.prepareStatement("SELECT * from guest WHERE access_code = ?;");
            //String Query = "select guest_id from guest ORDER BY guest_id DESC LIMIT 1;";
            
            ps.setString(1,accessCode);
            
            ResultSet rs = ps.executeQuery();
            
            if(rs.next()){
                
               guest = new Guest(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5));
               
            }
            
        } catch (Exception e) {
            e.printStackTrace();
        
        }
        
        
        return guest;
    }
    
    public static Event getEvent(int eventId){
    
        Event event = null;
                
        try {
            
            openConnection();
            Statement st = conn.createStatement();
            PreparedStatement ps = conn.prepareStatement("SELECT * from event WHERE event_id = ?;");
            //String Query = "select guest_id from guest ORDER BY guest_id DESC LIMIT 1;";
            
            ps.setInt(1,eventId);
            
            ResultSet rs = ps.executeQuery();
            
            if(rs.next()){
                
               event = new Event(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5));
               
            }
            
        } catch (Exception e) {
            e.printStackTrace();
        
        }
        
        return event;
    }
    
    /** Returns a guest that matches the given id, else returns null if no guest matches the given id*/
    public static Guest getGuest(int guestId){  
        
        Guest guest = null;
        
         
        try {
            
            openConnection();
            Statement st = conn.createStatement();
            PreparedStatement ps = conn.prepareStatement("SELECT * from guest WHERE guest_id = ?;");
            //String Query = "select guest_id from guest ORDER BY guest_id DESC LIMIT 1;";
            
            ps.setInt(1,guestId);
            
            ResultSet rs = ps.executeQuery();
            
            if(rs.next()){
                
               guest = new Guest(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5));
               
            }
            
        } catch (Exception e) {
            e.printStackTrace();
        
        }
        
        return guest;
    }
    
    /**get all events*/
    public static ArrayList<Event> getEventArray(){
        
        
        
        ArrayList<Event> EventArray = new ArrayList<>();
        
        try {
            
            openConnection();
            Statement st = conn.createStatement();
            //PreparedStatement ps = conn.prepareStatement("SELECT * from guest WHERE guest_id = ?;");
            String Query = "SELECT * from event ORDER BY event_id;";
            
            
            
            ResultSet rs = st.executeQuery(Query);
            
            while(rs.next()){
                
               EventArray.add(new Event(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5)));
               
            }
            
        } catch (Exception e) {
            e.printStackTrace();
        
        }
        
        return EventArray;
    }
    
    /**DATABASE TEST METHOD*/
    public static void test(String test){
            
        try {
            
            openConnection();
            Statement st = conn.createStatement();
          
            String Query = "SELECT e.event_id, count(r.rsvp_id) FROM rsvp r, invitation i, event e WHERE r.invitation_id = i.invitation_id AND i.event_id = e.event_id AND r.decision='Y' AND e.event_id=1 GROUP BY e.event_id";
            
            
            //Query = "SELECT * from rsvp";
            
            ResultSet rs = st.executeQuery(Query);
            
            if(rs.next()){
               
                System.out.println("SOMETHING");
                
                do{
                    //System.out.println(rs.getInt(1) + " - " + rs.getString(2) + " - " + rs.getString(3) + " - " + rs.getString(4)); 
                    System.out.println(rs.getInt(1) + " - " + rs.getInt(2));
                }while(rs.next());
               
               
            }else{
                System.out.println("NOTHING");
            }
            
        } catch (Exception e) {
            e.printStackTrace();
        
        }
    } 
    
    public static HashMap<RsvpDecision, Integer> getRsvpCountForEvent(int eventId){
        
        HashMap<RsvpDecision, Integer> hashMap = new HashMap<>();
        
        try {
            
            openConnection();
            Statement st = conn.createStatement();
          
            String Query = "SELECT e.event_id, count(r.rsvp_id) FROM rsvp r, invitation i, event e WHERE r.invitation_id = i.invitation_id AND i.event_id = e.event_id AND r.decision='Y' AND e.event_id=" + eventId + " GROUP BY e.event_id";
            ResultSet rs = st.executeQuery(Query);
            
            if(rs.next()){
                hashMap.put(RsvpDecision.Y,rs.getInt(2));
            }else{
                hashMap.put(RsvpDecision.Y,0);       
            }
            
            
            Query = "SELECT e.event_id, count(r.rsvp_id) FROM rsvp r, invitation i, event e WHERE r.invitation_id = i.invitation_id AND i.event_id = e.event_id AND r.decision='N' AND e.event_id=" + eventId + " GROUP BY e.event_id";
            rs = st.executeQuery(Query);
            
            if(rs.next()){
                hashMap.put(RsvpDecision.N,rs.getInt(2));
            }else{
                hashMap.put(RsvpDecision.N,0);       
            }
            
            
            Query = "SELECT e.event_id, count(r.rsvp_id) FROM rsvp r, invitation i, event e WHERE r.invitation_id = i.invitation_id AND i.event_id = e.event_id AND r.decision='U' AND e.event_id=" + eventId + " GROUP BY e.event_id";
            rs = st.executeQuery(Query);
            int U_Count = 0;
            
            if(rs.next()){
                U_Count = rs.getInt(2);
            }
            
            Query = "SELECT e.event_id, count(i.invitation_id) FROM invitation i, event e WHERE i.event_id = e.event_id "
                    + "AND i.invitation_id NOT IN (SELECT inv.invitation_id FROM invitation inv, rsvp rs WHERE rs.invitation_id=inv.invitation_id AND inv.event_id=" + eventId + ") "
                    + "AND e.event_id=" + eventId + " GROUP BY e.event_id";
            rs = st.executeQuery(Query);
            
            if(rs.next()){
                U_Count += rs.getInt(2);
            }
            
            hashMap.put(RsvpDecision.U,U_Count);
            
        } catch (Exception e) {
            e.printStackTrace();
        
        }
        
        return hashMap;
    }
    
    /**Creates the database tables*/
    public static void createLoginTable(){
        
        openConnection();
        String Query;
        try {
        
            Statement st = conn.createStatement();
            Query = "Create table if not exists Admin"
                        + "(admin_id INTEGER PRIMARY KEY,"
                        + "username TEXT NOT NULL,"
                        + "password TEXT NOT NULL);"; 
            st.execute(Query);
            
            Query = "Create table if not exists Guest"
                        + "(guest_id INTEGER PRIMARY KEY,"
                        + "access_code TEXT NOT NULL,"
                        + "email_address TEXT NOT NULL,"
                        + "phone_number TEXT NOT NULL,"
                        + "full_name TEXT NOT NULL);";
            st.execute(Query);
            
            Query = "Create table if not exists Event"
                        + "(event_id INTEGER PRIMARY KEY,"
                        + "event_name TEXT NOT NULL,"
                        + "start_time TEXT CHECK (start_time is DATETIME(start_time) and start_time is NOT NULL),"
                        + "address TEXT NOT NULL,"
                        + "special_instructions TEXT NOT NULL);";
            st.execute(Query);
            
            Query = "Create table if not exists Invitation"
                        + "(invitation_id INTEGER PRIMARY KEY,"
                        + "event_id INTEGER NOT NULL,"
                        + "guest_id INTEGER NOT NULL,"
                        + "admin_id INTEGER NOT NULL,"
                        + "FOREIGN KEY (event_id) REFERENCES event (event_id),"
                        + "FOREIGN KEY (guest_id) REFERENCES guest (guest_id),"
                        + "FOREIGN KEY (admin_id) REFERENCES admin (admin_id)"
                    + ");";  
            st.execute(Query);
            
            
            Query = "Create table if not exists rsvp"
                        + "(rsvp_id INTEGER PRIMARY KEY,"
                        + "invitation_id INTEGER NOT NULL,"
                        + "rsvp_datetime TEXT CHECK (rsvp_datetime is DATETIME(rsvp_datetime) and rsvp_datetime is NOT NULL),"
                        + "decision TEXT CHECK (decision in (\"Y\",\"N\",\"U\") and decision is NOT NULL),"
                        + "dietary_requirements TEXT,"
                        + "FOREIGN KEY (invitation_id) REFERENCES invitation (invitation_id)"
                        + ");";
            st.execute(Query);
            
            Query = "Create table if not exists run_sheet_time_slot"
                    + "(event_id INTEGER NOT NULL,"
                    + "time_slot TEXT CHECK (time_slot is TIME(time_slot) and time_slot is NOT NULL),"
                    + "description TEXT NOT NULL,"
                    + "FOREIGN KEY (event_id) REFERENCES event (event_id),"
                    + "PRIMARY KEY (event_id, time_slot)"
                    + ");";
            st.execute(Query);
            
            Query = "INSERT INTO admin VALUES (1,'admin','admin');";
            st.execute(Query);
            //Query = "INSERT INTO guest VALUES (1,'accesscode1','testguest1@gmail.com','02342423','Test Guest 1');";
            //st.execute(Query);
            //Query = "INSERT INTO guest VALUES (2,'accesscode2','testguest2@gmail.com','02347273','Test Guest 2');";
            //st.execute(Query);
            //Query = "INSERT INTO guest VALUES (3,'accesscode3','testguest3@gmail.com','08235625','Test Guest 3');";
            //st.execute(Query);
            //Query = "INSERT INTO guest VALUES (4,'accesscode4','testguest4@gmail.com','073246523','Test Guest 4');";
            //st.execute(Query);
            //Query = "INSERT INTO guest VALUES (5,'accesscode4','testguest4@gmail.com','073246523','Brandon Belikoff');";
            //st.execute(Query);
            
            //Query = "INSERT INTO event VALUES (1,'Test event one','2020-04-15 11:06:09','32 yarah drive, NSW','no shoes');";
            //st.execute(Query);
            //Query = "INSERT INTO event VALUES (2,'Test event two','2020-03-03 14:00:00','9 ant road, QLD','no clothes');";
            //st.execute(Query);
            //Query = "INSERT INTO invitation VALUES (1,1,1,1);";
            //st.execute(Query);
            //Query = "INSERT INTO invitation VALUES (2,2,1,1);";
            //st.execute(Query);
            //Query = "INSERT INTO invitation VALUES (3,1,5,1);";
            //st.execute(Query);
            
        }catch(SQLException ex){
            System.out.println( "SQL ERROR - " + ex.getMessage());
        }
             
       
    }
    
    public static boolean updateRunSheetTimeSlot(int eventId, String timeSlot, String newTime, String newdescription){
        
        boolean updated = false;
        
        try {      
            openConnection();
            PreparedStatement ps = conn.prepareStatement("UPDATE run_sheet_time_slot SET time_slot = ?, description = ? WHERE event_id = ? and time_slot = ?");
            
            ps.setString(1, newTime);
            ps.setString(2, newdescription);
            ps.setInt(3, eventId);
            ps.setString(4, timeSlot);
            ps.execute();    
            updated = true;
            
        } catch (Exception e) {
            e.printStackTrace();
        
        }
        
        return updated;
    }
    
    public static boolean AddRunSheetTimeSlot(int eventId, String timeSlot, String description){
        boolean added = false;
        
        try {
            
            openConnection();
            Statement st = conn.createStatement();
            PreparedStatement ps = conn.prepareStatement("INSERT INTO run_sheet_time_slot values (?,?,?);");
 
            ps.setInt(1, eventId);
            ps.setString(2, timeSlot);
            ps.setString(3, description);          
            ps.execute();
            
            added = true;
            
        } catch (Exception e) {
            e.printStackTrace();
        
        }
        
        return added;
    }

    /**Returns a array of time slots for a RunSheet for the given event*/
    public static ArrayList<RunSheetTimeSlot> getRunSheetTimeSlotArray(int eventId){
        
        ArrayList<RunSheetTimeSlot> timeSlotArray = new ArrayList<RunSheetTimeSlot>();
        
        
        try {
            
            openConnection();
            Statement st = conn.createStatement();
            PreparedStatement ps = conn.prepareStatement("SELECT * from run_sheet_time_slot WHERE event_id = ? ORDER BY TIME(time_slot);");
            //String Query = "SELECT * from guest ORDER BY guest_id DESC;";
            
            ps.setInt(1, eventId);
            
            
            ResultSet rs = ps.executeQuery();
            
            while(rs.next()){
                
               timeSlotArray.add(new RunSheetTimeSlot(rs.getInt(1),rs.getString(2),rs.getString(3)));
               
            }
            
        } catch (Exception e) {
            e.printStackTrace();
        
        }
        
        
        return timeSlotArray;
    }
    
    public static boolean addEvent (Event event){
        
        boolean added = false;
        
        try {
            
            openConnection();
            PreparedStatement ps = conn.prepareStatement("INSERT INTO event values (?,?,?,?,?);");
            
            ps.setInt(1, event.getEventId());
            ps.setString(2, event.getEventName());
            ps.setString(3, event.getStartTime());
            ps.setString(4, event.getAddress());
            ps.setString(5, event.getSpecialInstructions());
            ps.execute();
            
            added = true;
            
        } catch (Exception e) {
            e.printStackTrace();
        
        }
        
        return added;
    }
    
    /**Adds event generating a new Id*/
    public static boolean addEvent(String eventName, String startTime, String address, String specialInstructions){
       
        boolean added = false;
                  
         try {
            
            openConnection();
            Statement st = conn.createStatement();
            PreparedStatement ps = conn.prepareStatement("INSERT INTO event values (?,?,?,?,?);");
            int ID = 1;
            
            String Query = "select event_id from event ORDER BY event_id DESC LIMIT 1;";
            
            ResultSet rs = st.executeQuery(Query);
            
            if(rs.next()){
                
                ID = rs.getInt(1) + 1; //incrementing id
                
            }
            
            ps.setInt(1, ID);
            ps.setString(2, eventName);
            ps.setString(3, startTime);
            ps.setString(4, address);
            ps.setString(5, specialInstructions);
            ps.execute();
            
            added = true;
            
        } catch (Exception e) {
            e.printStackTrace();
        
        }
         
         return added;
    }
    
//    public static boolean addInvitation(Invitation invitation){
//        
//        boolean added = false;
//        
//        try {
//            
//            openConnection();
//            PreparedStatement ps = conn.prepareStatement("INSERT INTO event values (?,?,?,?);");
//            
//            ps.setInt(1, invitation.getInvitationId());
//            ps.setInt(2, invitation.getEventId());
//            ps.setInt(3, invitation.getGuestId());
//            ps.setInt(4, invitation.getAdminId());
//            ps.execute();
//            
//            added = true;
//            
//        } catch (Exception e) {
//            e.printStackTrace();
//        
//        }
//        
//        return added;
//    
//    }
    
    /**Returns a invitation between an event and a guest */
    public static Invitation getInvitation(int eventId, int guestId){
        Invitation invitation = null;
        
        try {
            
            openConnection();
            Statement st = conn.createStatement();

            
            String Query = "SELECT * FROM invitation WHERE event_id=" + eventId + " and guest_id=" + guestId + ";";
            ResultSet rs = st.executeQuery(Query);
            
            if(rs.next()){
                invitation = new Invitation(rs.getInt(1),rs.getInt(2),rs.getInt(3),rs.getInt(4));
            } 
            
        } catch (Exception e) {
            e.printStackTrace();
        
        }
        return invitation;
    }
    
    public static boolean addInvitation(int eventId, int guestId, int adminId){
    
        boolean added = false;
                  
         try {
            
            openConnection();
            Statement st = conn.createStatement();
            PreparedStatement ps = conn.prepareStatement("INSERT INTO invitation values (?,?,?,?);");
            int ID = 1;
            
            String Query = "SELECT * FROM invitation WHERE event_id=" + eventId + " and guest_id=" + guestId + ";";
            ResultSet rs = st.executeQuery(Query);
            if(rs.next()){
                //invite already exists
                return true;
            }
            
            
            Query = "select invitation_id from invitation ORDER BY invitation_id DESC LIMIT 1;";
            rs = st.executeQuery(Query);
            
            if(rs.next()){
                
                ID = rs.getInt(1) + 1; //incrementing id
                
            }
            
            ps.setInt(1, ID);
            ps.setInt(2, eventId);
            ps.setInt(3, guestId);
            ps.setInt(4, adminId);
            ps.execute();
            
            added = true;
            
        } catch (Exception e) {
            e.printStackTrace();
        
        }
         
         return added;
        
    }
    
    public static Admin getAdmin(String username, String password){
        
        Admin admin = null;
        
        try {
            
            openConnection();
            //Statement st = conn.createStatement();
            PreparedStatement ps = conn.prepareStatement("SELECT * from admin WHERE username=? and password=?;");
            
            ps.setString(1,username);
            ps.setString(2,password);
            
            ResultSet rs = ps.executeQuery();
            
            if(rs.next()){
                
               admin = new Admin(rs.getInt(1),rs.getString(2),rs.getString(3));
               
            }
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        
        return admin;
    }
    
    public static Admin getAdmin(int ID){
        
        Admin admin = null;
        
        try {
            
            openConnection();
            Statement st = conn.createStatement();
            PreparedStatement ps = conn.prepareStatement("SELECT * from admin WHERE admin_id=?;");
            
            ps.setInt(1,ID);
            
            ResultSet rs = ps.executeQuery();
            
            if(rs.next()){
                
               admin = new Admin(rs.getInt(1),rs.getString(2),rs.getString(3));
               
            }
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        
        return admin;
    }
    /**Adds rsvp to the database, will update the original rsvp if one exist (ie. wont create a new rsvp is one already exist for the given invitation ID)*/
    public static boolean addRsvp(int invitationID, RsvpDecision decision, String dietaryRequirements ){
        boolean added = false;
        
        try {
            
            openConnection();
            Statement st = conn.createStatement();
            PreparedStatement ps = conn.prepareStatement("INSERT INTO rsvp values (?,?,?,?,?);");
            int ID;
            ResultSet rs;   
            String rsvpTime;
            String decisionString = decision.toString();
            
            DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
            LocalDateTime now = LocalDateTime.now();
            rsvpTime = dtf.format(now);
            
            String Query = "SELECT * FROM rsvp WHERE invitation_id = " + invitationID;
            rs = st.executeQuery(Query);
            
            if(rs.next()){
                //rsvp for this invitation already exits, so update it rather than creating a new one
                
                System.out.println("rsvp already exists");
                int originalID = rs.getInt(1);
                
                PreparedStatement ps2 = conn.prepareStatement("UPDATE rsvp SET decision = ?, dietary_requirements = ?, rsvp_datetime = ? WHERE rsvp_id = ?");
                
                
                
                
                ps2.setString(1, decisionString);
                ps2.setString(2, dietaryRequirements);
                ps2.setString(3, rsvpTime);
                ps2.setInt(4, originalID);
                ps2.execute();
            
            }else{
                
                Query = "SELECT rsvp_id FROM rsvp ORDER BY rsvp_id DESC LIMIT 1;";
            
                rs = st.executeQuery(Query);
            
                if(rs.next()){
                
                    ID = rs.getInt(1) + 1; //incrementing id
                
                }else{
                    ID = 1;
                }
            
                ps.setInt(1, ID);
                ps.setInt(2, invitationID);
                ps.setString(3, rsvpTime);
                ps.setString(4, decisionString);
                ps.setString(5, dietaryRequirements);
                ps.execute();
            }
            
            
            
            
            added = true;
            
        } catch (Exception e) {
            e.printStackTrace();
        
        }
        
        
        return added;
        
    }
    
    /**Returns an array of events that the guest has been invited to, ordered by event_id*/
    public static ArrayList<Event> getInvitedEventsArray(int guestID){
    
        ArrayList<Event> EventArray = new ArrayList<>();
        
        try {
            
            openConnection();
            Statement st = conn.createStatement();
            PreparedStatement ps = conn.prepareStatement("SELECT * from event WHERE event_id in (SELECT event_id from invitation where guest_id=?) ORDER BY event_id;");
            //String Query = "SELECT * from guest ORDER BY guest_id DESC;";
            
            ps.setInt(1, guestID);
            
            
            ResultSet rs = ps.executeQuery();
            
            while(rs.next()){
                
                EventArray.add(new Event(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5)));
               
            }
            
        } catch (Exception e) {
                e.printStackTrace();
        
        }
        
        return EventArray;
        
    }
    
}
package Classes;


/*  
    ID and isAdmin can only be assigned once at the first instance. 
    Will remain the same and user static variables will be unchangeable until progaram is closed.
*/
public class User {
    
    private static User singleInstance = null; 
    
    private static int ID;
    private static boolean isAdmin = false;
    
    
    public static Guest guestSelected;
    public static Event eventSelected;
    public static Invitation invitationSelected;
    public static Rsvp rsvpSelected;
    
    public User(int ID, boolean isAdmin){
        
        if(singleInstance == null){
            this.ID = ID;
            this.isAdmin = isAdmin;
            singleInstance = this;
        }
    }
    
    public static int getUserId(){
        return ID;
    }
    
    public static boolean getUserIsAdmin(){
        return isAdmin;
    }
    
    public static void logOut(){
        singleInstance = null;
        ID = -1;
        isAdmin = false;
        guestSelected = null;
        eventSelected = null;
        invitationSelected = null;
        rsvpSelected = null;
    }
}

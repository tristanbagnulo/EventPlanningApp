package Classes;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.event.ActionEvent;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.text.Text;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import javafx.scene.Node;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.Label;
import javafx.stage.DirectoryChooser;

import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.font.PDFont;
import org.apache.pdfbox.pdmodel.font.PDTrueTypeFont;
import org.apache.pdfbox.pdmodel.font.PDType0Font;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.apache.pdfbox.pdmodel.graphics.image.PDImageXObject;


public class ARunSheetChooseEventController {

    @FXML
    private TableView<Event> eventTable;
    
    @FXML
    private TableColumn<Event, Number> IdColumn;
    
    @FXML
    private TableColumn<Event, String> nameColumn;
    
    
    ArrayList<Event> eventList;
    
    @FXML 
    private Button logout;
    
    @FXML
    private Button about;
    
    @FXML
    private Button events;
    
    @FXML
    private Button guest;
    
    @FXML
    private Button runsheet;
    
    @FXML
    private Button createRunsheet;
    
    @FXML
    private Button editRunsheet;
    
    @FXML
    private Label errorText;
    
    private Event selectedEvent;
    
    
    
    
    @FXML
    public void initialize() {
       
        
        
        eventList = Database.getEventArray();
        eventTable.setItems(FXCollections.observableArrayList(eventList));
        
                
        nameColumn.setCellValueFactory(cellData -> cellData.getValue().getEventNameProperty());
        IdColumn.setCellValueFactory(cellData -> cellData.getValue().getEventIdProperty());
        
        errorText.setText("");
    }   
    
    @FXML
    private void tableSelection(){
        
        selectedEvent = eventTable.getSelectionModel().getSelectedItem(); 
        
    }
    
    @FXML
    private void switchToAbout(ActionEvent event) throws IOException {
       
        System.out.println("Switching pages");
        Parent parent = FXMLLoader.load(getClass().getResource("/fxml/A-AboutPage.fxml"));
        Scene scene = new Scene(parent);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.setResizable(false);
        stage.show();
    } 
    
    @FXML
    private void switchToEvents(ActionEvent event) throws IOException {
       
        System.out.println("Switching pages");
        Parent parent = FXMLLoader.load(getClass().getResource("/fxml/A-ExistingEvent.fxml"));
        Scene scene = new Scene(parent);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.setResizable(false);
        stage.show();
    } 
    
    @FXML
    private void switchToGuest(ActionEvent event) throws IOException {
       
        System.out.println("Switching pages");
        Parent parent = FXMLLoader.load(getClass().getResource("/fxml/A-GuestSelectToEdit.fxml"));
        Scene scene = new Scene(parent);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.setResizable(false);
        stage.show();
    } 
    
    @FXML
    private void switchToInvitation(ActionEvent event) throws IOException {
       
        System.out.println("Switching pages");
        Parent parent = FXMLLoader.load(getClass().getResource("/fxml/A-Invitation-ChooseEvent.fxml"));
        Scene scene = new Scene(parent);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.setResizable(false);
        stage.show();
    } 
    
    @FXML
    private void switchToLogin(ActionEvent event) throws IOException {
        System.out.println("Switching to Login page");
        User.logOut();
        switchPage("EventPlannerLogin",event);
    }
    
    @FXML
    private void switchPage(String page, ActionEvent event) throws IOException {
       
        System.out.println("Switching pages");
        Parent parent = FXMLLoader.load(getClass().getResource("/fxml/" + page + ".fxml"));
        Scene scene = new Scene(parent);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.setResizable(false);
        stage.show();

    }
    
    @FXML
    private void create(ActionEvent event)throws IOException {
        
        if(selectedEvent == null){
            errorText.setText("No selection");
            return;
        }
        
        User.eventSelected = selectedEvent;
        
        Parent parent = FXMLLoader.load(getClass().getResource("/fxml/A-RunsheetCreateRunsheet.fxml"));
        Scene scene = new Scene(parent);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.setResizable(false);
        stage.show();
        
        
    }
    
    @FXML
    private void Download(ActionEvent event){
    
        if(selectedEvent == null){
            errorText.setText("No event selected");
            return;
        }
        
        String fileName = "RunSheet" + selectedEvent.getEventName() + ".pdf";
        DirectoryChooser dirChooser = new DirectoryChooser();
        
        File file = dirChooser.showDialog(((Node) event.getSource()).getScene().getWindow());
        
        if(file == null){
            errorText.setText("File location not selected");
            return;
        }
        
        String imageName = "invitationBG.jpg";
        
        ArrayList<RunSheetTimeSlot> timeSlotArray = Database.getRunSheetTimeSlotArray(selectedEvent.getEventId());
        
        
        try{
            PDDocument doc = new PDDocument();
            PDPage page = new PDPage();           
            
            //adding image
            PDImageXObject image = PDImageXObject.createFromFile(imageName, doc);
            PDPageContentStream content = new PDPageContentStream(doc, page);    
            content.drawImage(image, 0, 0, 620, 800);
            
            //importing fonts
            PDFont proximaReg = PDType0Font.load(doc, new File( "proximanova-regular.ttf" ));
            PDFont pls = PDType0Font.load( doc, new File( "PlaylistScript.ttf" ));  
 
            doc.addPage(page);    
            
            content.beginText();
            content.newLineAtOffset(100, 750);
            content.setFont(proximaReg, 20);
            content.showText("RunSheet for event: " + selectedEvent.getEventName());
            content.newLineAtOffset(0, -70);
            
            int counter = 680;
            
            for(RunSheetTimeSlot slot: timeSlotArray){
                
                
                content.setFont(proximaReg, 15);
                content.showText(slot.getTimeSlot().substring(0, 5) + "     " + slot.getDescription());
                content.newLineAtOffset(0, -20);
                counter -= 20;
                
                
                if(counter < 150){
                    counter = 700;
                    PDPage pageTemp = new PDPage();
                    content = new PDPageContentStream(doc, pageTemp);
                    content.drawImage(image, 0, 0, 620, 800);
                    doc.addPage(pageTemp);
                    content.beginText();
                    content.newLineAtOffset(100, 700);
                    
                }
                
            }
                     

            
            content.endText();
            content.close();
            
            doc.save(file.getAbsoluteFile()+File.separator+fileName);
            doc.close();
            
        }catch(IOException e){
            errorText.setText("Download error");
            System.out.println("Exception catch - " + e.getMessage());
            return;
        }
        
        errorText.setText("Saved");
        
    }
    
    @FXML
    private void edit(ActionEvent event)throws IOException {
        
        if(selectedEvent == null){
            errorText.setText("No selection");
            return;
        }
        
        User.eventSelected = selectedEvent;
        
        Parent parent = FXMLLoader.load(getClass().getResource("/fxml/A-RunsheetEditRunsheet.fxml"));
        Scene scene = new Scene(parent);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.setResizable(false);
        stage.show();
        
        
    }

}

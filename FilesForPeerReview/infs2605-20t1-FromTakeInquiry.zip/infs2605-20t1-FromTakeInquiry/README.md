# infs2605-20t1-FromTakeInquiry
infs2605-20t1-FromTakeInquiry
